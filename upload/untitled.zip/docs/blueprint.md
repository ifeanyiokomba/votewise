# **App Name**: Okomba Elections

## Core Features:

- Voter Verification: Verify student credentials (matric number, department, level) against a database before allowing access to the voting dashboard. Provides contact options if the user is not found.
- OTVP Delivery: Send a one-time verification PIN (OTVP) via Email, WhatsApp, or SMS based on available voter details. Resend option available after a 60-second timer.
- Voting Dashboard: Sleek voting page to display contestants grouped by position. Voters can select a candidate per position. Presents summary and final confirmation before recording the vote in the database. Auto updates in real-time.
- Real-time Election Results: Display auto-updating real-time results for contestants on the homepage in a sleek, dynamic format (e.g., charts or lists that refresh automatically).
- Observer Dashboard: Provide observers with real-time analytics of voter activities, tools to resend OTVP, search voter registration status, and view voter details.
- Admin Dashboard: A comprehensive admin section to manage contestants, voters, observers, and system configurations. It contains upload tools and manual entry as well.
- Chatbot Support: A floating chatbot powered by a reasoning tool that connects voters with admins/observers, supports text, file and image uploads. Chat sessions automatically become private between the voter and responding observer with admin oversight.

## Style Guidelines:

- Primary color: Deep purple (#483D8B) for trust, authority, and a sense of importance, befitting an election platform.
- Background color: Very light lavender (#F0F0F8), nearly white, offering a clean, neutral backdrop that keeps focus on content.
- Accent color: Royal blue (#4169E1) provides highlights that draw attention and support user interaction.
- Body: 'Inter', a sans-serif font, giving a modern machined and objective look that works in headlines or body.
- Headers: 'Space Grotesk' for headlines and titles, a geometric sans-serif font, with a techy scientific feel.
- Use modern, minimalist icons throughout the application to aid navigation and represent key actions and information.
- Employ a clean, grid-based layout with ample whitespace to ensure readability and visual appeal.
- Subtle transitions and animations will enhance user experience. Animated charts and graphs, animated countdown timer etc.