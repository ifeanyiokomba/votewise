
import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

admin.initializeApp();

const db = admin.firestore();

/**
 * A Cloud Function to securely cast a vote.
 *
 * This function is callable from the client and performs the vote counting
 * transaction on the server-side, preventing clients from directly
 * manipulating vote counts. It also updates a separate, public-facing
 * collection with the aggregated results.
 */
export const castVote = functions.https.onCall(async (data, context) => {
  // 1. Authentication Check
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "The function must be called while authenticated."
    );
  }

  const { selections, matricNumber } = data;
  const voterId = context.auth.uid;
  
  functions.logger.info(`Processing vote from voterId: ${voterId}`, { selections });


  // 2. Data Validation
  if (!selections || typeof selections !== "object" || !matricNumber) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "The function must be called with 'selections' and a 'matricNumber'."
    );
  }
  
  try {
    // 3. Secure Server-Side Transaction
    await db.runTransaction(async (transaction) => {
      // We use the matric number as the canonical ID for a voter record.
      const voterRef = db.collection("voters").doc(matricNumber);
      const voterDoc = await transaction.get(voterRef);

      if (!voterDoc.exists) {
          throw new functions.https.HttpsError(
              "not-found",
              "Voter record not found with the provided matriculation number."
          );
      }
      
      if (voterDoc.data()?.hasVoted) {
          functions.logger.warn(`Attempted re-vote by matricNumber: ${matricNumber}`);
          throw new functions.https.HttpsError(
              "failed-precondition",
              "This user has already voted."
          );
      }

      // Mark the voter as having voted in the private voters collection.
      transaction.update(voterRef, { hasVoted: true });
      
      // Atomically update vote counts for each selection
      for (const position in selections) {
        const contestantId = selections[position];
        if (typeof contestantId === "string") {
          const resultRef = db.collection("results").doc(contestantId);
          const electionResultRef = db.collection("electionResults").doc(contestantId);

          const resultDoc = await transaction.get(resultRef);
          const currentVotes = resultDoc.data()?.votes || 0;
          const newVoteCount = currentVotes + 1;
          
          // Increment the private vote count
          transaction.set(resultRef, { votes: newVoteCount }, { merge: true });
          
          // Update the public-facing aggregated result
          transaction.set(electionResultRef, { votes: newVoteCount }, { merge: true });
        }
      }
    });
    
    // Clean up the temporary session document
    const sessionRef = db.collection("sessions").doc(voterId);
    await sessionRef.delete();
    
    functions.logger.info(`Vote successfully cast for voterId: ${voterId}`);
    return { success: true, message: "Vote cast successfully." };

  } catch (error) {
    functions.logger.error(`Error casting vote for voterId: ${voterId}`, error);
    if (error instanceof functions.https.HttpsError) {
        throw error;
    }
    // 4. Error Handling
    throw new functions.https.HttpsError(
      "internal",
      "An error occurred while casting the vote."
    );
  }
});


/**
 * Callable Cloud Function to set a custom user role.
 * Only callable by users who are already admins.
 */
export const setUserRole = functions.https.onCall(async (data, context) => {
  // Check if the caller is an admin by checking custom claims.
  if (context.auth?.token.role !== 'admin') {
     throw new functions.https.HttpsError('permission-denied', 'Only admins can set user roles.');
  }

  const { uid, role } = data;
  if (!uid || !role) {
       throw new functions.https.HttpsError('invalid-argument', 'The function must be called with "uid" and "role" arguments.');
  }

  try {
    // Set custom claims on the user's auth token
    await admin.auth().setCustomUserClaims(uid, { role });
    
    // Also update the roles in the /users collection for client-side queries and rule checks
    await db.collection('users').doc(uid).set({ roles: [role] }, { merge: true });
    
    return { success: true, message: `Role '${role}' set for user ${uid} successfully.` };
  } catch (error) {
    console.error('Error setting user role:', error);
    // Corrected the typo from httpsG to https
    throw new functions.https.HttpsError('internal', 'An error occurred while setting the user role.');
  }
});

/**
 * Trigger to set up a user document in Firestore on new user creation.
 * This ensures that a user has a default role of 'voter',
 * but assigns 'admin' role for the special admin email.
 */
exports.setupUserOnLogin = functions.auth.user().onCreate(async (user) => {
  const userRef = admin.firestore().collection('users').doc(user.uid);
  let role = 'voter'; // Default role
  
  // Special case: If the user's email is the admin email, assign the 'admin' role.
  if (user.email === 'support@okomba.com') {
      role = 'admin';
  }

  // Set the custom claim for the determined role
  await admin.auth().setCustomUserClaims(user.uid, { role });

  // Create the user document in firestore for client-side visibility and security rules
  await userRef.set({
    uid: user.uid,
    roles: [role],
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  
  console.log(`User ${user.uid} created with role: ${role}`);
  return { success: true, role };
});
