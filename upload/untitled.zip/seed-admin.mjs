
import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

const serviceAccount = {
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
  privateKey: (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
};

if (!serviceAccount.projectId || !serviceAccount.clientEmail || !serviceAccount.privateKey) {
  console.error('Firebase Admin credentials are not set in .env file. Exiting.');
  process.exit(1);
}

// Initialize Firebase Admin
const app = initializeApp({
  credential: cert(serviceAccount),
});

const auth = getAuth(app);
const firestore = getFirestore(app);

const ADMIN_EMAIL = 'admin@okomba.com';
const ADMIN_PASSWORD = 'Ntaokomba91615';

async function seedAdmin() {
  console.log('--- Starting Admin Seeding Script ---');

  try {
    let userRecord;
    
    // 1. Check if user exists
    try {
      userRecord = await auth.getUserByEmail(ADMIN_EMAIL);
      console.log(`Admin user '${ADMIN_EMAIL}' already exists with UID: ${userRecord.uid}.`);
    } catch (error) {
      if (error.code === 'auth/user-not-found') {
        // 2. If user does not exist, create them
        console.log(`Admin user '${ADMIN_EMAIL}' not found. Creating...`);
        userRecord = await auth.createUser({
          email: ADMIN_EMAIL,
          password: ADMIN_PASSWORD,
          displayName: 'Okomba Admin',
          emailVerified: true,
        });
        console.log(`Successfully created admin user with UID: ${userRecord.uid}`);
      } else {
        // Rethrow other errors
        throw error;
      }
    }

    const uid = userRecord.uid;
    const currentClaims = userRecord.customClaims || {};

    // 3. Set custom claim for 'admin' role
    if (currentClaims.role !== 'admin') {
      console.log(`Setting 'admin' custom claim for user ${uid}...`);
      await auth.setCustomUserClaims(uid, { role: 'admin' });
      console.log('Custom claim set successfully.');
    } else {
      console.log(`User ${uid} already has 'admin' custom claim.`);
    }

    // 4. Create or update user document in Firestore '/users' collection
    const userDocRef = firestore.collection('users').doc(uid);
    console.log(`Ensuring Firestore document exists at /users/${uid}...`);
    await userDocRef.set({
      uid: uid,
      roles: ['admin'],
    }, { merge: true });
    console.log('Firestore document is up to date.');

    console.log('--- Admin Seeding Script Finished Successfully ---');
    process.exit(0);
  } catch (error) {
    console.error('--- Admin Seeding Script Failed ---');
    console.error('Error details:', error);
    process.exit(1);
  }
}

seedAdmin();
