
// @ts-check
import { getAdminApp } from './src/firebase/admin.js';

/**
 * This script creates a specific observer user in Firebase Authentication and Firestore.
 * It assigns them the 'observer' role and creates their profile documents.
 */
async function seedNewObserver() {
  console.log('--- Starting Observer Seeding Script ---');

  // Observer details from your request
  const observer = {
    email: 'observer@okomba.com',
    password: 'Ntaokomba91615',
    fullName: 'Okomba Ifeanyichukwu',
    phoneNumber: '08088948657' // Note: phone number is not part of the base observer schema but kept for reference
  };
  
  try {
    const adminApp = getAdminApp();
    const auth = adminApp.auth();
    const firestore = adminApp.firestore();
    
    console.log(`Checking if observer ${observer.email} already exists...`);

    let userRecord;
    try {
        userRecord = await auth.getUserByEmail(observer.email);
        console.log(`User ${observer.email} already exists with UID: ${userRecord.uid}. Updating details...`);
        
        // Update user details in Auth
        await auth.updateUser(userRecord.uid, {
            password: observer.password,
            displayName: observer.fullName,
            photoURL: `https://avatar.vercel.sh/${observer.email}.png`,
        });

    } catch (error) {
        if (error.code === 'auth/user-not-found') {
            console.log(`User ${observer.email} not found. Creating new user...`);
            // 1. Create user in Firebase Auth
            userRecord = await auth.createUser({
                email: observer.email,
                password: observer.password,
                displayName: observer.fullName,
                photoURL: `https://avatar.vercel.sh/${observer.email}.png`,
            });
            console.log(`Successfully created new user: ${observer.email} with UID: ${userRecord.uid}`);
        } else {
            // Rethrow other errors
            throw error;
        }
    }

    const uid = userRecord.uid;

    // 2. Set the custom claim for 'observer' role
    console.log(`Setting 'observer' role claim for UID: ${uid}`);
    await auth.setCustomUserClaims(uid, { role: 'observer' });

    // 3. Create the user document in /users collection for security rules
    console.log(`Creating/updating document in /users/${uid}`);
    const userRolePromise = firestore.collection('users').doc(uid).set({
        roles: ['observer']
    }, { merge: true });

    // 4. Create the observer profile document in /observers collection
    console.log(`Creating/updating document in /observers/${uid}`);
    const observerProfilePromise = firestore.collection('observers').doc(uid).set({
        id: uid,
        fullName: observer.fullName,
        email: observer.email,
        photoURL: `https://avatar.vercel.sh/${observer.email}.png`,
    }, { merge: true });

    await Promise.all([userRolePromise, observerProfilePromise]);

    console.log('\n✅ Observer seeding complete!');
    console.log('You can now log in with the following credentials:');
    console.log(`   Email: ${observer.email}`);
    console.log(`   Password: ${observer.password}`);
    
  } catch (error) {
    console.error('❌ Error during observer seeding:');
    if (error.code === 'auth/email-already-exists') {
      console.error(`   The email address "${observer.email}" is already in use by another account.`);
    } else {
      console.error('   ' + error.message);
    }
  } finally {
    console.log('--- Finished Observer Seeding Script ---');
    // The script will exit automatically.
  }
}

seedNewObserver();
