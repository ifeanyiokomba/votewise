'use server';

/**
 * @fileOverview A Genkit flow for summarizing voter feedback from chatbot logs.
 *
 * - summarizeVoterFeedback - A function that summarizes voter feedback.
 * - SummarizeVoterFeedbackInput - The input type for the summarizeVoterFeedback function.
 * - SummarizeVoterFeedbackOutput - The return type for the summarizeVoterFeedback function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeVoterFeedbackInputSchema = z.object({
  feedbackLogs: z
    .string()
    .describe("The voter feedback logs to summarize."),
});
export type SummarizeVoterFeedbackInput = z.infer<typeof SummarizeVoterFeedbackInputSchema>;

const SummarizeVoterFeedbackOutputSchema = z.object({
  summary: z.string().describe('A summary of the voter feedback.'),
});
export type SummarizeVoterFeedbackOutput = z.infer<typeof SummarizeVoterFeedbackOutputSchema>;

export async function summarizeVoterFeedback(
  input: SummarizeVoterFeedbackInput
): Promise<SummarizeVoterFeedbackOutput> {
  return summarizeVoterFeedbackFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeVoterFeedbackPrompt',
  input: {schema: SummarizeVoterFeedbackInputSchema},
  output: {schema: SummarizeVoterFeedbackOutputSchema},
  prompt: `You are an AI assistant helping to summarize voter feedback logs.

  Summarize the following voter feedback to identify common issues and areas for improvement in the election process:

  Feedback Logs: {{{feedbackLogs}}}
  `,
});

const summarizeVoterFeedbackFlow = ai.defineFlow(
  {
    name: 'summarizeVoterFeedbackFlow',
    inputSchema: SummarizeVoterFeedbackInputSchema,
    outputSchema: SummarizeVoterFeedbackOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
