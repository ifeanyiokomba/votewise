
'use client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Vote, Percent, PieChart as PieChartIcon } from 'lucide-react';
import { departmentAnalytics, levelAnalytics } from '@/lib/data';
import { Progress } from '@/components/ui/progress';
import { memo } from 'react';

const totalVotes = 1450;
const eligibleVoters = 2500;
const turnout = (totalVotes / eligibleVoters) * 100;

const StatCard = memo(({ title, value, icon: Icon, progress }: { title: string, value: string | number, icon: React.ElementType, progress?: number }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      {progress !== undefined && (
        <>
        <p className="text-xs text-muted-foreground mt-1">
            {totalVotes.toLocaleString()} of {eligibleVoters.toLocaleString()} voters
        </p>
        <Progress value={progress} className="mt-2 h-2" />
        </>
      )}
    </CardContent>
  </Card>
));
StatCard.displayName = 'StatCard';


function AnalyticsDashboardComponent() {
  return (
    <div className="space-y-6">
       <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Votes Cast" value={totalVotes.toLocaleString()} icon={Vote} />
        <StatCard title="Total Eligible Voters" value={eligibleVoters.toLocaleString()} icon={Users} />
        <StatCard title="Voter Turnout" value={`${turnout.toFixed(1)}%`} icon={Percent} progress={turnout} />
        <StatCard title="Contested Positions" value={Object.keys(departmentAnalytics).length} icon={PieChartIcon} />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Voter Distribution by Department</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {departmentAnalytics.map(entry => (
                <div key={entry.department} className="flex justify-between items-center">
                  <span>{entry.department}</span>
                  <span className="font-bold">{entry.votes}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Voter Distribution by Level</CardTitle>
          </CardHeader>
          <CardContent>
             <div className="space-y-2">
              {levelAnalytics.map(entry => (
                <div key={entry.level} className="flex justify-between items-center">
                  <span>{entry.level}</span>
                  <span className="font-bold">{entry.votes}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export const AnalyticsDashboard = memo(AnalyticsDashboardComponent);
