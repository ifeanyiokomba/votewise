'use server';

import { getAdminApp } from '@/firebase/admin';

interface ElectionSettingsData {
  startDate: string | null;
  endDate: string | null;
  isElectionActive: boolean;
}

export async function getElectionSettings(): Promise<{ success: boolean; settings?: ElectionSettingsData; message?: string }> {
  try {
    const adminApp = await getAdminApp();
    const firestore = adminApp.firestore();
    const settingsDoc = await firestore.doc('settings/election').get();

    if (!settingsDoc.exists) {
      return { success: true, settings: { startDate: null, endDate: null, isElectionActive: false } };
    }

    const data = settingsDoc.data();
    
    return {
      success: true,
      settings: {
        startDate: data?.startDate.toDate().toISOString() || null,
        endDate: data?.endDate.toDate().toISOString() || null,
        isElectionActive: data?.isElectionActive || false,
      },
    };
  } catch (error: any) {
    console.error('Error fetching election settings:', error);
    // In a production environment, you might not want to expose the raw error message
    return { success: false, message: 'Could not retrieve election settings.' };
  }
}

    