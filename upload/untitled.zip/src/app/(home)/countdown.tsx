
'use client';

import { useState, useEffect, memo } from 'react';

type TimeUnit = {
  value: number;
  label: string;
};

const calculateTimeLeft = (targetDate: Date) => {
  const difference = +targetDate - +new Date();
  let timeLeft: { [key: string]: number } = {};

  if (difference > 0) {
    timeLeft = {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((difference / 1000 / 60) % 60),
      seconds: Math.floor((difference / 1000) % 60),
    };
  }

  return timeLeft;
};

const TimeValue = memo(({ value, label }: TimeUnit) => (
  <div className="flex flex-col items-start p-4 rounded-lg">
    <span className="text-6xl md:text-7xl font-bold font-mono text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 tracking-tighter leading-none">
      {String(value).padStart(2, '0')}
    </span>
    <span className="text-sm text-muted-foreground uppercase tracking-widest">{label}</span>
  </div>
));
TimeValue.displayName = 'TimeValue';

export function Countdown({ targetDate, onComplete }: { targetDate: Date, onComplete: () => void }) {
  const [timeLeft, setTimeLeft] = useState<{ [key: string]: number }>({});
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    // This ensures this code runs only on the client, after hydration
    setIsClient(true); 

    const timer = setInterval(() => {
      const newTimeLeft = calculateTimeLeft(targetDate);
      setTimeLeft(newTimeLeft);

      if (Object.keys(newTimeLeft).length === 0) {
        onComplete();
        clearInterval(timer);
      }
    }, 1000);
    
    // Set initial time to avoid 1-second delay
    setTimeLeft(calculateTimeLeft(targetDate));

    return () => clearInterval(timer);
  }, [targetDate, onComplete]);


  if (!isClient || Object.keys(timeLeft).length === 0) {
    return <div className="text-left text-xl font-bold text-primary">Loading...</div>;
  }

  const timerComponents: TimeUnit[] = [
    { value: timeLeft.days || 0, label: 'Days' },
    { value: timeLeft.hours || 0, label: 'Hours' },
    { value: timeLeft.minutes || 0, label: 'Mins' },
    { value: timeLeft.seconds || 0, label: 'Secs' },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4 gap-2 md:gap-4 -ml-4">
      {timerComponents.map((unit) => (
        <TimeValue key={unit.label} {...unit} />
      ))}
    </div>
  );
}
