import { VoteNowButton } from './vote-now-button';
import { cn } from '@/lib/utils';

export function Hero({ electionEnded }: { electionEnded: boolean }) {
  return (
    <section className="text-center py-16 md:py-24 relative">
      <div className="flex flex-col items-center">
        <h1 className="font-headline text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-400">
          The Future of Voting
        </h1>
        <p className="mt-6 max-w-2xl text-lg md:text-xl text-muted-foreground">
          Experience a secure, transparent, and efficient voting process. Your voice, your vote, your future—now just a click away.
        </p>
      </div>
      <div className={cn('mt-10 md:mt-12', 'relative z-10')}>
        <VoteNowButton disabled={electionEnded} />
      </div>
    </section>
  );
}

    