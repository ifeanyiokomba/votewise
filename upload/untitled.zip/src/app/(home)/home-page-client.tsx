
'use client';

import { Hero } from '@/app/(home)/hero';
import { Countdown } from '@/app/(home)/countdown';
import { Winners } from '@/app/(home)/winners';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useState, useMemo, useCallback, useEffect } from 'react';
import { Monitor, Trophy, ShieldQuestion, Circle, Loader2, Users, BarChart3 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { getElectionSettings } from './actions';
import { RealtimePresidentialResults } from './realtime-presidential-results';

interface ElectionSettings {
  startDate: Date | null;
  endDate: Date | null;
  isElectionActive?: boolean;
}

export function HomePageClient() {
  const { toast } = useToast();
  
  const [electionSettings, setElectionSettings] = useState<ElectionSettings | null>(null);
  const [isLoadingSettings, setIsLoadingSettings] = useState(true);
  const [electionStatus, setElectionStatus] = useState<'loading' | 'pending' | 'active' | 'ended'>('loading');
  const [targetDate, setTargetDate] = useState<Date | null>(null);

  useEffect(() => {
    async function fetchSettings() {
      setIsLoadingSettings(true);
      const result = await getElectionSettings();
      if (result.success && result.settings) {
        setElectionSettings({
          startDate: result.settings.startDate ? new Date(result.settings.startDate) : null,
          endDate: result.settings.endDate ? new Date(result.settings.endDate) : null,
          isElectionActive: result.settings.isElectionActive,
        });
      } else {
        // Handle case where settings are not found or an error occurs
        setElectionSettings(null);
      }
      setIsLoadingSettings(false);
    }
    fetchSettings();
  }, []);

  const isVotingActive = useMemo(() => electionSettings?.isElectionActive ?? false, [electionSettings]);

  useEffect(() => {
    if (isLoadingSettings) {
      setElectionStatus('loading');
      return;
    }

    if (!electionSettings || !electionSettings.startDate || !electionSettings.endDate) {
        setElectionStatus('pending'); // No settings found, election hasn't been configured
        setTargetDate(null);
        return;
    }
    
    const now = new Date();
    const startDate = electionSettings.startDate;
    const endDate = electionSettings.endDate;

    if (now > endDate) {
      setElectionStatus('ended');
      setTargetDate(null);
    } else if (now >= startDate && electionSettings.isElectionActive) {
      setElectionStatus('active');
      setTargetDate(endDate);
    } else if (now < startDate) {
      setElectionStatus('pending');
      setTargetDate(startDate);
    } else { // After start time, but not manually activated
      setElectionStatus('pending'); // Treat as pending until admin starts it
      setTargetDate(startDate);
    }
  }, [electionSettings, isLoadingSettings]);

  const handleCountdownComplete = useCallback(() => {
    if (electionStatus === 'active') {
        setElectionStatus('ended');
        toast({
            title: "Election Over",
            description: "The voting period has officially ended. An admin must now stop the election.",
        });
    } else if (electionStatus === 'pending') {
         // This state is now controlled by the admin, but we can reflect the change locally.
         // We can't definitively switch to 'active' as it requires an admin action.
         // A page refresh would get the latest state.
         toast({
            title: "Election Start Time Reached",
            description: "The scheduled start time has passed. An admin must activate the election for voting to begin.",
         });
    }
  }, [electionStatus, toast]);

  const renderRightPanelContent = () => {
    switch (electionStatus) {
      case 'ended':
        return {
          icon: <Trophy className="h-6 w-6 text-primary"/>,
          title: 'Official Winners',
          description: 'The official election results are in.',
          content: <Winners />
        };
      case 'active':
        return {
          icon: <BarChart3 className="h-6 w-6 text-primary"/>,
          title: 'Live Election Results',
          description: 'Results are updated in real-time.',
          content: <RealtimePresidentialResults />
        };
      case 'pending':
      case 'loading':
      default:
        return {
          icon: <BarChart3 className="h-6 w-6 text-primary"/>,
          title: 'Live Election Results',
          description: 'Results will appear here once voting starts.',
          content: (
            <div className="flex items-center justify-center h-48 text-muted-foreground">
                <p>Awaiting start of election...</p>
            </div>
          )
        };
    }
  };

  const rightPanel = renderRightPanelContent();

  return (
    <>
      <Hero electionEnded={!isVotingActive && electionStatus === 'ended'} />
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 md:gap-12 mt-12 md:mt-20 items-start">
        <div className="lg:col-span-2">
            <Card className="bg-transparent border-0 shadow-none">
                <CardHeader className="p-0">
                    <CardTitle className="font-headline text-3xl md:text-4xl text-left">
                     {electionStatus === 'loading' && 'Loading Status...'}
                     {electionStatus === 'pending' && 'Election Countdown'}
                     {electionStatus === 'active' && 'Election Countdown'}
                     {electionStatus === 'ended' && 'Election Over'}
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-0 pt-6">
                    {electionStatus === 'loading' && <Loader2 className="h-8 w-8 animate-spin" />}
                    {(electionStatus === 'pending' || electionStatus === 'active') && targetDate ? (
                      <>
                        <Countdown targetDate={targetDate} onComplete={handleCountdownComplete} />
                        <div className="mt-6 flex items-center justify-start text-left">
                            <div className="relative flex-shrink-0 mr-3">
                                <Circle className={cn("h-5 w-5", isVotingActive ? "text-green-500 fill-green-500 animate-pulse" : "text-gray-500 fill-gray-500")} />
                                {isVotingActive && <div className="absolute inset-0 rounded-full bg-green-500 animate-pulse blur-md opacity-75" style={{boxShadow: '0 0 10px hsl(var(--primary))' }}></div>}
                            </div>
                            <p className="text-base italic text-white/90" style={{textShadow: isVotingActive ? '1px 1px 3px hsl(var(--primary))' : 'none'}}>
                                {isVotingActive ? 'Election in progress, monitored and recorded' : 'Election is not yet active. Awaiting admin start.'}
                            </p>
                        </div>
                      </>
                    ) : null}
                     {electionStatus === 'ended' && (
                        <>
                            <div className="text-left text-lg md:text-xl font-bold text-red-500">The election has finished. Check out the results!</div>
                            <div className="mt-6 flex items-center justify-start text-left">
                                <div className="relative flex-shrink-0 mr-3">
                                    <Circle className="h-5 w-5 text-red-500 fill-red-500" />
                                    <div className="absolute inset-0 rounded-full bg-red-500/50 blur-md"></div>
                                </div>
                                <p className="text-base italic text-white/90">
                                    Election ended!
                                </p>
                            </div>
                        </>
                    )}
                    {electionStatus === 'pending' && !targetDate && !isLoadingSettings && (
                        <div className="text-left text-lg md:text-xl font-bold text-primary">The election date has not been set yet.</div>
                    )}
                </CardContent>
            </Card>
        </div>
        
        <div className="lg:col-span-3">
          <Card className="bg-white/5 border-white/10 text-card-foreground shadow-2xl backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-md">
                    {rightPanel.icon}
                  </div>
                  <div>
                    <CardTitle className="font-headline text-xl md:text-2xl flex items-center gap-2">
                        {rightPanel.title}
                    </CardTitle>
                    <CardDescription>
                        {rightPanel.description}
                    </CardDescription>
                  </div>
              </div>
            </CardHeader>
            <CardContent>
                {rightPanel.content}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
