
'use client';

import { useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { useFirestore } from '@/firebase';
import { contestants } from '@/lib/data';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2 } from 'lucide-react';
import { useMemo } from 'react';


export function RealtimeResults() {
  const firestore = useFirestore();

  const resultsQuery = useMemoFirebase(() => {
    // The query is now public and does not depend on a user being authenticated.
    if (!firestore) return null;
    return query(collection(firestore, 'electionResults'), orderBy('votes', 'desc'));
  }, [firestore]);

  const { data: results, isLoading, error } = useCollection<{ votes: number }>(resultsQuery);

  const chartData = useMemo(() => {
    if (!results) return [];

    const allContestants = Object.values(contestants).flat();

    return allContestants.map(candidate => {
      const result = results.find(r => r.id === candidate.id);
      return {
        name: candidate.name,
        votes: result?.votes || 0,
      };
    }).sort((a, b) => b.votes - a.votes);
  }, [results]);


  if (isLoading && !results) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading live results...</span>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Error Loading Results</AlertTitle>
        <AlertDescription>Could not fetch real-time election data. The service may be temporarily unavailable.</AlertDescription>
      </Alert>
    );
  }
  
  if (chartData.length === 0) {
     return (
      <Alert>
        <AlertTitle>Awaiting First Votes</AlertTitle>
        <AlertDescription>The polls are open! Live results will appear here as soon as the first votes are cast.</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-2 max-h-64 overflow-y-auto">
      {chartData.map((candidate) => (
        <div key={candidate.name} className="flex justify-between items-center p-2 bg-secondary/50 rounded-md">
          <span className="text-sm font-semibold">{candidate.name}</span>
          <span className="font-bold text-primary">{candidate.votes.toLocaleString()}</span>
        </div>
      ))}
    </div>
  );
}
