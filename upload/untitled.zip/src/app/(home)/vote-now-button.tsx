'use client';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Vote } from 'lucide-react';

export function VoteNowButton({ disabled }: { disabled: boolean }) {
  const router = useRouter();

  const handleClick = () => {
    router.push('/vote/verify');
  };

  return (
    <div>
      <Button
        onClick={handleClick}
        size="lg"
        disabled={disabled}
        className={cn(
          'h-16 px-12 text-xl font-bold rounded-full shadow-lg',
          'bg-gradient-to-r from-primary to-accent text-primary-foreground',
          'transition-all duration-300 ease-in-out',
          'hover:shadow-2xl hover:shadow-primary/40',
          'disabled:cursor-not-allowed disabled:opacity-100 disabled:hover:shadow-lg disabled:bg-gray-500 disabled:bg-none'
        )}
      >
          <Vote className="mr-3 h-6 w-6"/>
          {disabled ? 'Voting Closed' : 'Vote Now'}
      </Button>
    </div>
  );
}

    
