
'use client';

import Image from 'next/image';
import { electionWinners } from '@/lib/data';
import { Card, CardContent } from '@/components/ui/card';
import { Crown } from 'lucide-react';

export function Winners() {
  return (
    <div className="grid grid-cols-1 gap-4">
      {Object.entries(electionWinners).map(([position, winner]) => (
        <Card key={position} className="bg-transparent border-0 shadow-none">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="relative flex-shrink-0">
                <Image
                    src={winner.photoUrl}
                    alt={`Photo of ${winner.name}`}
                    width={80}
                    height={80}
                    data-ai-hint="portrait"
                    className="rounded-full border-2 border-accent object-cover aspect-square"
                />
                 <div className="absolute -top-1 -right-1 bg-accent text-white p-1.5 rounded-full shadow-lg">
                    <Crown className="h-4 w-4" />
                </div>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-lg text-amber-400">{position} - Elect</p>
              <h4 className="font-bold text-xl text-foreground">{winner.name}</h4>
              <p className="text-sm text-muted-foreground">{winner.department}</p>
            </div>
             <div className="flex flex-col items-center justify-center p-3 rounded-md bg-secondary text-center">
                <p className="text-xs text-muted-foreground">Votes</p>
                <p className="text-2xl font-bold text-primary">{winner.votes.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
