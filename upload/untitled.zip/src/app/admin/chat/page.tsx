
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { AdminChatConsole } from "@/components/chat/admin-chat-console";

export default function AdminChatPage() {
    return (
        <div className="space-y-8">
            <div className="flex justify-between items-start">
                <div>
                    <h1 className="font-headline text-4xl font-bold text-primary">Chat Support Console</h1>
                    <p className="text-muted-foreground">Monitor and respond to voter support requests in real-time.</p>
                </div>
            </div>

            <Card className="h-[75vh] flex flex-col">
                <CardHeader>
                    <CardTitle>Voter Support Tickets</CardTitle>
                    <CardDescription>Select a ticket from the left panel to view details and take action.</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                   <AdminChatConsole />
                </CardContent>
            </Card>
        </div>
    );
}
