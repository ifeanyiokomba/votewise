
'use server';

import { getAdminApp } from '@/firebase/admin';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { getStorage } from 'firebase-admin/storage';

const contestantFormSchema = z.object({
  fullName: z.string().min(3, 'Full name must be at least 3 characters.'),
  department: z.string({ required_error: 'Please select a department.' }),
  position: z.string({ required_error: 'Please select a position.' }),
  shortPhrase: z.string().min(5, 'Phrase must be at least 5 characters.').max(50, 'Phrase must be 50 characters or less.'),
  headshotUrl: z.string().url({ message: 'Invalid URL format.' }),
});


export async function createContestant(
  formData: FormData
): Promise<{ success: boolean; message: string }> {
  const validatedData = contestantFormSchema.safeParse({
      fullName: formData.get('fullName'),
      department: formData.get('department'),
      position: formData.get('position'),
      shortPhrase: formData.get('shortPhrase'),
      headshotUrl: formData.get('headshotUrl'),
  });

  if (!validatedData.success) {
    return { success: false, message: validatedData.error.errors.map(e => e.message).join(', ') };
  }

  const { ...contestantData } = validatedData.data;

  try {
    const adminApp = await getAdminApp();
    const firestore = adminApp.firestore();
    
    await firestore.collection('contestants').add({
      ...contestantData
    });

    revalidatePath('/admin/contestants');
    return { success: true, message: 'Contestant added successfully.' };

  } catch (error: any) {
    console.error('Error creating contestant:', error);
    if (error.code === 'permission-denied') {
        return { success: false, message: `Firestore Permission Denied: The current user does not have permission to create documents in the 'contestants' collection. Please check security rules.` };
    }
    return { success: false, message: error.message || 'An unexpected error occurred.' };
  }
}

export async function deleteContestant(
  contestantId: string,
  headshotUrl: string
): Promise<{ success: boolean; message: string }> {
  try {
    const adminApp = await getAdminApp();
    const firestore = adminApp.firestore();

    // 1. Delete Firestore document
    await firestore.collection('contestants').doc(contestantId).delete();

    // 2. If the headshot is from Firebase Storage, delete it
    if (headshotUrl.includes('storage.googleapis.com')) {
      const storage = getStorage(adminApp);
      // Extract file path from the URL
      const decodedUrl = decodeURIComponent(headshotUrl);
      const filePath = decodedUrl.substring(decodedUrl.indexOf('/o/') + 3, decodedUrl.indexOf('?alt=media'));
      
      if (filePath) {
        try {
            const bucket = storage.bucket();
            await bucket.file(filePath).delete();
        } catch (storageError: any) {
            // Log the storage error but don't block the UI response if the file is already gone
            console.warn(`Could not delete storage file ${filePath}:`, storageError.message);
        }
      }
    }
    
    revalidatePath('/admin/contestants');
    return { success: true, message: 'Contestant deleted successfully.' };

  } catch (error: any) {
    console.error('Error deleting contestant:', error);
    if (error.code === 'permission-denied') {
        return { success: false, message: `Firestore Permission Denied: The current user does not have permission to delete documents from the 'contestants' collection. Please check security rules.` };
    }
    return { success: false, message: error.message || 'An unexpected error occurred.' };
  }
}
