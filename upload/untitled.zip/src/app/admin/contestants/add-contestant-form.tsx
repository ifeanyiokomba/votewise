
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, UserPlus, Link2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { createContestant } from './actions';
import { departments, positions } from '@/lib/data';
import { useState } from 'react';

const contestantFormSchema = z.object({
  fullName: z.string().min(3, 'Full name must be at least 3 characters.'),
  department: z.string({ required_error: 'Please select a department.' }),
  position: z.string({ required_error: 'Please select a position.' }),
  shortPhrase: z.string().min(5, 'Phrase must be at least 5 characters.').max(50, 'Phrase must be 50 characters or less.'),
  headshotUrl: z.string().url({ message: "Please enter a valid image URL." }),
});

export function AddContestantForm() {
  const { toast } = useToast();
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const form = useForm<z.infer<typeof contestantFormSchema>>({
    resolver: zodResolver(contestantFormSchema),
    defaultValues: {
      fullName: '',
      department: '',
      position: '',
      shortPhrase: '',
      headshotUrl: '',
    },
  });
  
  const { isSubmitting } = form.formState;

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setImagePreview(e.target.value);
  };

  async function onSubmit(values: z.infer<typeof contestantFormSchema>) {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => {
      if (value) {
          formData.append(key, value);
      }
    });

    const result = await createContestant(formData);

    if (result.success) {
      toast({
        title: 'Contestant Added',
        description: `${values.fullName} has been successfully added.`,
      });
      form.reset();
      setImagePreview(null);
    } else {
      toast({
        variant: 'destructive',
        title: 'Action Failed',
        description: result.message || 'Could not add the contestant.',
      });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-2xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                    <Input placeholder="e.g. John Doe" {...field} />
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
            />
             <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>Department</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                        <SelectTrigger>
                        <SelectValue placeholder="Select contestant's department" />
                        </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        {departments.map(dep => <SelectItem key={dep} value={dep}>{dep}</SelectItem>)}
                    </SelectContent>
                    </Select>
                    <FormMessage />
                </FormItem>
                )}
            />
             <FormField
                control={form.control}
                name="position"
                render={({ field }) => (
                <FormItem>
                    <FormLabel>Position</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                        <SelectTrigger>
                        <SelectValue placeholder="Select position they are running for" />
                        </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        {positions.map(pos => <SelectItem key={pos} value={pos}>{pos}</SelectItem>)}
                    </SelectContent>
                    </Select>
                    <FormMessage />
                </FormItem>
                )}
            />
            
            <div className="md:col-span-2">
                 <FormField
                    control={form.control}
                    name="headshotUrl"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Headshot Image URL</FormLabel>
                            <FormControl>
                                <div className="relative">
                                    <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"/>
                                    <Input 
                                        placeholder="https://example.com/image.png" 
                                        {...field} 
                                        onChange={(e) => {
                                            field.onChange(e);
                                            handleUrlChange(e);
                                        }}
                                        className="pl-9"
                                    />
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
            </div>

            <div className="md:col-span-2">
                <FormField
                    control={form.control}
                    name="shortPhrase"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Short Phrase / Slogan</FormLabel>
                        <FormControl>
                            <Input placeholder="A short, catchy phrase for the ballot" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
        </div>

        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          <UserPlus className="mr-2 h-4 w-4" />
          Add Contestant
        </Button>
      </form>
    </Form>
  );
}
