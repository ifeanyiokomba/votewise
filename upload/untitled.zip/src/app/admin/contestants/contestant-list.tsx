
'use client';

import { useState } from 'react';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Trash2, UserX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { deleteContestant } from './actions';

interface Contestant {
    id: string;
    fullName: string;
    department: string;
    position: string;
    headshotUrl: string;
    shortPhrase: string;
}

function ContestantListComponent() {
    const firestore = useFirestore();
    const { toast } = useToast();
    const [isDeleting, setIsDeleting] = useState<string | null>(null);

    const contestantsQuery = useMemoFirebase(() => {
        if (!firestore) return null;
        return query(collection(firestore, 'contestants'), orderBy('fullName'));
    }, [firestore]);

    const { data: contestants, isLoading } = useCollection<Contestant>(contestantsQuery);

    const handleDelete = async (contestant: Contestant) => {
        setIsDeleting(contestant.id);
        const result = await deleteContestant(contestant.id, contestant.headshotUrl);
        if (result.success) {
            toast({ title: 'Success', description: 'Contestant deleted successfully.' });
        } else {
            toast({ variant: 'destructive', title: 'Error', description: result.message });
        }
        setIsDeleting(null);
    };

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }
    
    if (!contestants || contestants.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center h-40 text-muted-foreground italic gap-2">
                <UserX className="h-10 w-10"/>
                <p>No contestants have been added yet.</p>
            </div>
        )
    }

    return (
        <div className="border rounded-md">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Contestant</TableHead>
                        <TableHead>Position</TableHead>
                        <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {contestants.map((contestant) => (
                        <TableRow key={contestant.id}>
                            <TableCell>
                                <div className="flex items-center gap-4">
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img 
                                        src={contestant.headshotUrl} 
                                        alt={contestant.fullName}
                                        width={40}
                                        height={40}
                                        className="rounded-full object-cover aspect-square"
                                    />
                                    <div>
                                        <p className="font-semibold">{contestant.fullName}</p>
                                        <p className="text-sm text-muted-foreground">{contestant.department}</p>
                                    </div>
                                </div>
                            </TableCell>
                            <TableCell>{contestant.position}</TableCell>
                            <TableCell className="text-right">
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button variant="ghost" size="icon" disabled={isDeleting === contestant.id}>
                                            {isDeleting === contestant.id ? <Loader2 className="h-4 w-4 animate-spin"/> : <Trash2 className="h-4 w-4 text-destructive" />}
                                        </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                            <AlertDialogDescription>
                                                This action will permanently delete <span className="font-bold">{contestant.fullName}</span> and their data. This cannot be undone.
                                            </AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => handleDelete(contestant)} className="bg-destructive hover:bg-destructive/90">
                                                Delete
                                            </AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}

export function ContestantList() {
    const firestore = useFirestore();

    if (!firestore) {
        return (
             <div className="flex justify-center items-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                 <span className="ml-2">Connecting to database...</span>
            </div>
        );
    }
    
    return <ContestantListComponent />;
}
