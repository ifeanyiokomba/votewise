
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { AddContestantForm } from "./add-contestant-form";
import { ContestantList } from "./contestant-list";
import { Suspense } from "react";
import { Loader2 } from "lucide-react";

export default function ContestantManagementPage() {
    return (
        <div className="space-y-8">
            <h1 className="font-headline text-4xl font-bold text-primary">Contestant Management</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Add New Contestant</CardTitle>
                    <CardDescription>Manually add a contestant to the ballot. All fields are required.</CardDescription>
                </CardHeader>
                <CardContent>
                    <AddContestantForm />
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Current Contestants</CardTitle>
                    <CardDescription>A list of all contestants currently in the election.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Suspense fallback={<div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
                        <ContestantList />
                    </Suspense>
                </CardContent>
            </Card>
        </div>
    );
}
