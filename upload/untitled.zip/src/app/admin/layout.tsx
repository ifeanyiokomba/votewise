'use client';

import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import Link from 'next/link';
import { BrandLogo } from '@/components/brand-logo';
import { LayoutDashboard, Users, Vote, Shield, Settings, MessageSquare, ListCollapse } from 'lucide-react';
import { UserNav } from './user-nav';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  // The authentication check is now handled by the individual page components
  // to prevent the layout from blocking the initial render.
  return (
    <SidebarProvider>
      <div className="flex min-h-screen">
        <Sidebar>
          <SidebarHeader>
            <BrandLogo />
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Dashboard">
                   <Link href="/admin" className="flex w-full items-center gap-2">
                    <LayoutDashboard />
                    <span>Dashboard</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Contestants">
                  <Link href="/admin/contestants" className="flex w-full items-center gap-2">
                    <Vote />
                    <span>Contestants</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Voters">
                   <Link href="/admin/voters" className="flex w-full items-center gap-2">
                    <Users />
                    <span>Voters</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Observers">
                  <Link href="/admin/observers" className="flex w-full items-center gap-2">
                    <Shield />
                    <span>Observers</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
               <SidebarMenuItem>
                <SidebarMenuButton tooltip="Chat Support">
                  <Link href="/admin/chat" className="flex w-full items-center gap-2">
                    <MessageSquare />
                    <span>Chat Support</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Activity Logs">
                  <Link href="/admin/logs" className="flex w-full items-center gap-2">
                    <ListCollapse />
                    <span>Activity Logs</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
               <SidebarMenuItem>
                <SidebarMenuButton tooltip="Settings">
                  <Link href="/admin/settings" className="flex w-full items-center gap-2">
                    <Settings />
                    <span>Settings</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>

        <SidebarInset>
            <header className="flex h-14 items-center gap-4 border-b bg-background/95 px-4 md:px-6 sticky top-0 z-30">
                <div className="flex items-center gap-2 md:hidden">
                    <SidebarTrigger />
                    <BrandLogo className="h-8 w-auto" />
                </div>
                <div className="flex-1">
                    {/* Can add search or other header items here */}
                </div>
                <UserNav />
            </header>
            <main className="flex-1 p-4 md:p-8 relative">
              {children}
            </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
