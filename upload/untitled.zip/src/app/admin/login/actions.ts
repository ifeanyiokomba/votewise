
'use server';

import { getAdminApp } from '@/firebase/admin';

export async function createAdminUser(): Promise<{ success: boolean; message: string }> {
  const adminEmail = 'support@okomba.com';
  const adminPassword = 'Ntaokomba91615';
  const adminFullName = 'Okomba Ifeanyichukwu';
  const adminPhoneNumber = '08088948657';

  try {
    const adminApp = await getAdminApp();
    const auth = adminApp.auth();
    const firestore = adminApp.firestore();

    let userRecord;

    // Check if user already exists
    try {
      userRecord = await auth.getUserByEmail(adminEmail);
      // User exists, ensure role and details are set
      await auth.setCustomUserClaims(userRecord.uid, { role: 'admin' });
      await firestore.collection('users').doc(userRecord.uid).set({ roles: ['admin'] }, { merge: true });

    } catch (error: any) {
      if (error.code === 'auth/user-not-found') {
        // User does not exist, create them
        userRecord = await auth.createUser({
          email: adminEmail,
          password: adminPassword,
          displayName: adminFullName,
        });

        // Set custom claim and firestore role
        await auth.setCustomUserClaims(userRecord.uid, { role: 'admin' });
        await firestore.collection('users').doc(userRecord.uid).set({ roles: ['admin'] });
      } else {
        // Re-throw other errors from getUserByEmail
        throw error;
      }
    }
    
    // Create or update the admin details in the /admins collection
    await firestore.collection('admins').doc(userRecord.uid).set({
        id: userRecord.uid,
        fullName: adminFullName,
        email: adminEmail,
        phoneNumber: adminPhoneNumber
    }, { merge: true });

    return { success: true, message: 'Admin user configured successfully.' };

  } catch (error: any) {
    console.error('Error in createAdminUser action:', error);
    return { success: false, message: error.message || 'An unexpected error occurred.' };
  }
}
