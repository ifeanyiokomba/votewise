
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Loader2, UserCog } from 'lucide-react';
import { useAuth } from '@/firebase';
import { signInWithEmailAndPassword, setPersistence, browserSessionPersistence } from 'firebase/auth';
import { createAdminUser } from './actions';
import { useState } from 'react';

const formSchema = z.object({
  email: z.string().email('Invalid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
});

export default function AdminLoginPage() {
    const router = useRouter();
    const { toast } = useToast();
    const auth = useAuth();
    const [isCreatingAdmin, setIsCreatingAdmin] = useState(false);
    
    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: { email: 'support@okomba.com', password: 'Ntaokomba91615' },
    });

    const { isSubmitting } = form.formState;

    async function handleSignIn(values: z.infer<typeof formSchema>) {
        if (!auth) {
            toast({ variant: 'destructive', title: "Error", description: "Authentication service is not available." });
            return;
        }

        try {
            await setPersistence(auth, browserSessionPersistence);
            await signInWithEmailAndPassword(auth, values.email, values.password);
            router.push('/admin');
        } catch (error: any) {
            console.error("Admin Login failed:", error);

            let description = "An unexpected error occurred. Please try again.";
            if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
                description = "Authentication failed. If this is the first time you are logging in, please use the 'First Time Setup' button to create the admin account.";
            } else if (error.code === 'auth/too-many-requests') {
                description = "Access to this account has been temporarily disabled due to many failed login attempts. You can try again later.";
            }
            toast({ variant: 'destructive', title: "Login Failed", description });
        }
    }

    async function handleEnsureAdminExists() {
        setIsCreatingAdmin(true);
        const result = await createAdminUser();
        if (result.success) {
            toast({
                title: "Admin Account Ready",
                description: result.message,
            });
        } else {
            toast({
                variant: 'destructive',
                title: "Admin Setup Failed",
                description: result.message,
            });
        }
        setIsCreatingAdmin(false);
    }


  return (
    <main className="flex-1 flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
            <div className="mx-auto bg-primary text-primary-foreground rounded-full h-16 w-16 flex items-center justify-center mb-4">
                <UserCog className="h-8 w-8" />
            </div>
          <CardTitle className="font-headline text-3xl">Admin Login</CardTitle>
          <CardDescription>Enter your administrator credentials.</CardDescription>
        </CardHeader>
        <CardContent>
            <Form {...form}>
                <form className="space-y-6">
                    <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                            <Input type="email" placeholder="admin@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                            <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <div className="flex flex-col gap-2">
                        <Button type="button" className="w-full" disabled={isSubmitting || isCreatingAdmin} onClick={form.handleSubmit(handleSignIn)}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Sign In
                        </Button>
                         <Button type="button" variant="outline" className="w-full" disabled={isSubmitting || isCreatingAdmin} onClick={handleEnsureAdminExists}>
                            {isCreatingAdmin && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            First Time Setup: Create Admin
                        </Button>
                    </div>
                </form>
            </Form>
        </CardContent>
      </Card>
    </main>
  );
}
