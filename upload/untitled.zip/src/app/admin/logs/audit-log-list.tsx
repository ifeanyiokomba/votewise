
'use client';

import { useState, useMemo, useCallback, useEffect } from 'react';
import { useFirestore } from '@/firebase';
import { collection, query, orderBy, limit, startAfter, getDocs, DocumentData, getCountFromServer, Firestore } from 'firebase/firestore';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, ChevronLeft, ChevronRight, User, Clock, Info, Shield, UserCog } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { format, formatDistanceToNow } from 'date-fns';
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';

interface AuditLog {
    id: string;
    userId: string;
    userName: string;
    userRole: 'admin' | 'observer';
    action: string;
    details: Record<string, any>;
    timestamp: { seconds: number, nanoseconds: number };
}

const PAGE_SIZE = 20;

export function AuditLogList() {
    const firestore = useFirestore();

    if (!firestore) {
        return (
            <div className="flex items-center justify-center h-40">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="ml-2">Connecting to database...</span>
            </div>
        )
    }

    return (
        <TooltipProvider>
            <PaginatedLogList firestore={firestore} />
        </TooltipProvider>
    );
}


function PaginatedLogList({ firestore }: { firestore: Firestore }) {
    const [logs, setLogs] = useState<AuditLog[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [pageCursors, setPageCursors] = useState<(DocumentData | null)[]>([null]);
    const [totalLogs, setTotalLogs] = useState(0);

    const totalPages = useMemo(() => Math.ceil(totalLogs / PAGE_SIZE), [totalLogs]);

    const fetchTotalLogs = useCallback(async () => {
        const coll = collection(firestore, 'auditLogs');
        const snapshot = await getCountFromServer(coll);
        setTotalLogs(snapshot.data().count);
    }, [firestore]);

    const fetchLogs = useCallback(async (pageNumber: number) => {
        setIsLoading(true);

        const logsCollection = collection(firestore, 'auditLogs');
        let q;
        const lastVisible = pageCursors[pageNumber - 1];
        
        if (pageNumber > 1 && lastVisible) {
            q = query(logsCollection, orderBy('timestamp', 'desc'), startAfter(lastVisible), limit(PAGE_SIZE));
        } else {
            q = query(logsCollection, orderBy('timestamp', 'desc'), limit(PAGE_SIZE));
        }
        
        try {
            const documentSnapshots = await getDocs(q);
            const newLogs = documentSnapshots.docs.map(doc => ({ id: doc.id, ...doc.data() } as AuditLog));
            setLogs(newLogs);

            if (documentSnapshots.docs.length > 0) {
                const lastDoc = documentSnapshots.docs[documentSnapshots.docs.length - 1];
                if (pageNumber === pageCursors.length) {
                    setPageCursors(prev => [...prev, lastDoc]);
                }
            }
        } catch (error) {
            console.error("Error fetching audit logs:", error);
            // Handle error display to user if needed
        } finally {
            setIsLoading(false);
        }
    }, [firestore, pageCursors]);

    useEffect(() => {
        fetchTotalLogs();
        fetchLogs(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [firestore]);

    const handleNextPage = () => {
        if (page < totalPages) {
            const newPage = page + 1;
            setPage(newPage);
            fetchLogs(newPage);
        }
    };

    const handlePrevPage = () => {
        if (page > 1) {
            const newPage = page - 1;
            setPage(newPage);
            fetchLogs(newPage);
        }
    };

    const RoleIcon = ({ role }: { role: 'admin' | 'observer' }) => {
        const icon = role === 'admin' 
            ? <UserCog className="h-4 w-4 text-destructive" /> 
            : <Shield className="h-4 w-4 text-sky-500" />;
        return <Tooltip>
            <TooltipTrigger asChild><Badge variant={role === 'admin' ? 'destructive' : 'secondary'} className="capitalize w-28 justify-center">{icon}<span className="ml-2">{role}</span></Badge></TooltipTrigger>
            <TooltipContent><p>{role}</p></TooltipContent>
        </Tooltip>
    }

    return (
        <>
            <div className="border rounded-md">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-48">User</TableHead>
                            <TableHead>Action</TableHead>
                            <TableHead className="w-56 text-right">Timestamp</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading && (
                            <TableRow>
                                <TableCell colSpan={3} className="h-40 text-center">
                                    <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
                                </TableCell>
                            </TableRow>
                        )}
                        {!isLoading && logs.map((log) => (
                            <TableRow key={log.id}>
                                <TableCell>
                                    <div className="flex flex-col">
                                        <span className="font-semibold">{log.userName}</span>
                                        <RoleIcon role={log.userRole} />
                                    </div>
                                </TableCell>
                                <TableCell>
                                     <div className="flex items-start gap-2">
                                        <Info className="h-4 w-4 mt-1 text-muted-foreground flex-shrink-0" />
                                        <div>
                                            <p className="font-medium">{log.action}</p>
                                            {log.details && (
                                                <p className="text-xs text-muted-foreground">
                                                    {Object.entries(log.details).map(([key, value]) => `${key}: ${value}`).join(', ')}
                                                </p>
                                            )}
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell className="text-right">
                                     <div className="flex flex-col items-end">
                                        <div className="flex items-center gap-2">
                                            <Clock className="h-4 w-4" />
                                            <span>{format(new Date(log.timestamp.seconds * 1000), 'MMM d, yyyy, h:mm a')}</span>
                                        </div>
                                        <p className="text-xs text-muted-foreground">{formatDistanceToNow(new Date(log.timestamp.seconds * 1000), { addSuffix: true })}</p>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                         {!isLoading && logs.length === 0 && (
                            <TableRow>
                                <TableCell colSpan={3} className="h-40 text-center text-muted-foreground">
                                    No activity logs found.
                                </TableCell>
                            </TableRow>
                         )}
                    </TableBody>
                </Table>
            </div>
            <div className="flex items-center justify-end space-x-2 py-4">
                <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
                <Button variant="outline" size="sm" onClick={handlePrevPage} disabled={page === 1}>
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                </Button>
                <Button variant="outline" size="sm" onClick={handleNextPage} disabled={page >= totalPages}>
                    Next
                    <ChevronRight className="h-4 w-4" />
                </Button>
            </div>
        </>
    );
}
