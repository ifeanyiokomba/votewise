
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { AuditLogList } from "./audit-log-list";
import { Suspense } from "react";
import { Loader2 } from "lucide-react";

export default function AuditLogPage() {
    return (
        <div className="space-y-8">
            <h1 className="font-headline text-4xl font-bold text-primary">Observer Activity Logs</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Activity Stream</CardTitle>
                    <CardDescription>A real-time log of all actions performed by election observers.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Suspense fallback={<div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin" /></div>}>
                        <AuditLogList />
                    </Suspense>
                </CardContent>
            </Card>
        </div>
    );
}
