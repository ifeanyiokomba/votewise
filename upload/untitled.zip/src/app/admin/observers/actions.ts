'use server';

import { getAdminApp } from '@/firebase/admin';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { getStorage } from 'firebase-admin/storage';
import { randomUUID } from 'crypto';

const formSchema = z.object({
  fullName: z.string().min(1, 'Full name is required.'),
  email: z.string().email('Invalid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
});

export async function createObserver(
  formData: FormData
): Promise<{ success: boolean; message: string }> {
    const validatedData = formSchema.safeParse({
        fullName: formData.get('fullName'),
        email: formData.get('email'),
        password: formData.get('password'),
    });

    const photo = formData.get('photo') as File;

    if (!validatedData.success) {
        return { success: false, message: validatedData.error.errors.map(e => e.message).join(', ') };
    }
    
    if (!photo || photo.size === 0) {
        return { success: false, message: 'A photo is required for the observer.' };
    }

    const { fullName, email, password } = validatedData.data;

    try {
        const adminApp = await getAdminApp();
        const auth = adminApp.auth();
        const firestore = adminApp.firestore();
        const storage = getStorage(adminApp);
        const bucket = storage.bucket();

        // 1. Upload photo to Firebase Storage
        const photoBuffer = Buffer.from(await photo.arrayBuffer());
        const photoFileName = `observer-photos/${randomUUID()}-${photo.name}`;
        const file = bucket.file(photoFileName);

        await file.save(photoBuffer, {
            metadata: {
                contentType: photo.type,
            },
        });
        
        // Make the file public and get its URL. In a real-world app, you might use signed URLs.
        await file.makePublic();
        const photoURL = file.publicUrl();

        // 2. Create user in Firebase Auth
        const userRecord = await auth.createUser({
            email,
            password,
            displayName: fullName,
            photoURL: photoURL,
        });

        // 3. Set the custom claim for 'observer' role
        await auth.setCustomUserClaims(userRecord.uid, { role: 'observer' });

        // 4. Create the user document in /users collection for security rules
        const userRolePromise = firestore.collection('users').doc(userRecord.uid).set({
            roles: ['observer']
        });

        // 5. Create the observer profile document in /observers collection
        const observerProfilePromise = firestore.collection('observers').doc(userRecord.uid).set({
            id: userRecord.uid,
            fullName,
            email,
            photoURL,
        });

        await Promise.all([userRolePromise, observerProfilePromise]);

        revalidatePath('/admin/observers');
        revalidatePath('/'); // Revalidate homepage to show new committee member

        return { success: true, message: 'Observer created successfully.' };

    } catch (error: any) {
        console.error('Error creating observer:', error);
        let message = 'An unexpected error occurred.';
        if (error.code === 'auth/email-already-exists') {
        message = 'This email address is already in use by another account.';
        } else if (error.message) {
            message = error.message;
        }
        return { success: false, message };
    }
}

export async function deleteObserver(observerId: string): Promise<{ success: boolean; message: string }> {
    try {
        const adminApp = await getAdminApp();
        const auth = adminApp.auth();
        const firestore = adminApp.firestore();

        // Get observer doc to find photo URL
        const observerDoc = await firestore.collection('observers').doc(observerId).get();
        const observerData = observerDoc.data();

        // 1. Delete user from Firebase Auth
        const deleteAuthPromise = auth.deleteUser(observerId);

        // 2. Delete observer from Firestore
        const deleteObserverPromise = firestore.collection('observers').doc(observerId).delete();
        
        // 3. Delete user role from users collection
        const deleteRolePromise = firestore.collection('users').doc(observerId).delete();

        // 4. Delete photo from Storage
        let deleteStoragePromise = Promise.resolve();
        if (observerData?.photoURL && observerData.photoURL.includes('storage.googleapis.com')) {
            const storage = getStorage(adminApp);
            const decodedUrl = decodeURIComponent(observerData.photoURL);
            const filePath = decodedUrl.substring(decodedUrl.indexOf('/o/') + 3, decodedUrl.indexOf('?alt=media'));
            
            if (filePath) {
                deleteStoragePromise = storage.bucket().file(filePath).delete().catch(err => {
                    // Log error if file deletion fails, but don't block the overall success
                    console.warn(`Could not delete storage file ${filePath}:`, err.message);
                });
            }
        }

        await Promise.all([deleteAuthPromise, deleteObserverPromise, deleteRolePromise, deleteStoragePromise]);

        revalidatePath('/admin/observers');
        revalidatePath('/'); // Revalidate homepage
        return { success: true, message: 'Observer deleted successfully.' };
    } catch (error: any) {
        console.error('Error deleting observer:', error);
        return { success: false, message: error.message || 'An unexpected error occurred.' };
    }
}
    

    