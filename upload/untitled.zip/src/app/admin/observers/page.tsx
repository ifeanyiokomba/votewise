
'use client';
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UserPlus, Trash2, Loader2, UserX, ChevronLeft, ChevronRight, Image as ImageIcon } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormMessage, FormLabel, FormDescription } from "@/components/ui/form";
import { createObserver, deleteObserver } from "./actions";
import { useToast } from "@/hooks/use-toast";
import Image from 'next/image';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { query, orderBy, limit, startAfter, getDocs, collection, DocumentData, getCountFromServer, Firestore } from "firebase/firestore";
import { useFirestore } from "@/firebase";


const formSchema = z.object({
  fullName: z.string().min(1, 'Full name is required.'),
  email: z.string().email('Invalid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
  photo: z.any(),
});

interface Observer {
    id: string;
    fullName: string;
    email: string;
    photoURL: string;
}

const PAGE_SIZE = 5;

function ObserverManagementComponent({ firestore }: { firestore: Firestore }) {
    const { toast } = useToast();
    const [isDeleting, setIsDeleting] = useState<string | null>(null);
    const photoInputRef = useRef<HTMLInputElement>(null);
    const [photoPreview, setPhotoPreview] = useState<string | null>(null);

    const [observers, setObservers] = useState<Observer[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [pageCursors, setPageCursors] = useState<(DocumentData | null)[]>([null]);
    const [totalObservers, setTotalObservers] = useState(0);

    const totalPages = useMemo(() => Math.ceil(totalObservers / PAGE_SIZE), [totalObservers]);

    const fetchTotalObservers = useCallback(async () => {
        try {
            const coll = collection(firestore, "observers");
            const snapshot = await getCountFromServer(coll);
            setTotalObservers(snapshot.data().count);
        } catch (error) {
            console.error("Error fetching total observers:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch total observer count.' });
        }
    }, [firestore, toast]);

    const fetchObservers = useCallback(async (pageNumber: number) => {
        setIsLoading(true);
        try {
            const observersCollection = collection(firestore, 'observers');
            let q;
            const lastVisible = pageCursors[pageNumber - 1];

            if (pageNumber > 1 && lastVisible) {
                q = query(observersCollection, orderBy('fullName'), startAfter(lastVisible), limit(PAGE_SIZE));
            } else {
                 q = query(observersCollection, orderBy('fullName'), limit(PAGE_SIZE));
            }
            
            const documentSnapshots = await getDocs(q);
            const newObservers = documentSnapshots.docs.map(doc => ({ id: doc.id, ...doc.data() } as Observer));
            setObservers(newObservers);

            if (documentSnapshots.docs.length > 0) {
                const lastDoc = documentSnapshots.docs[documentSnapshots.docs.length - 1];
                if (pageNumber >= pageCursors.length) {
                    setPageCursors(prev => [...prev, lastDoc]);
                }
            }
        } catch (error) {
            console.error("Error fetching observers:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch observers.' });
        } finally {
            setIsLoading(false);
        }
    }, [firestore, pageCursors, toast]);

    const refreshData = useCallback(() => {
        fetchTotalObservers();
        setPage(1);
        setPageCursors([null]);
        fetchObservers(1);
    }, [fetchObservers, fetchTotalObservers]);

    useEffect(() => {
        refreshData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [firestore]);


    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: { fullName: '', email: '', password: '' },
    });

    const { isSubmitting } = form.formState;

    async function onSubmit(values: z.infer<typeof formSchema>) {
        const formData = new FormData();
        Object.entries(values).forEach(([key, value]) => {
            if (key === 'photo' && photoInputRef.current?.files?.[0]) {
                formData.append('photo', photoInputRef.current.files[0]);
            } else if (value) {
                formData.append(key, value);
            }
        });

        const result = await createObserver(formData);
        if (result.success) {
            toast({ title: "Success", description: result.message });
            form.reset();
            setPhotoPreview(null);
            if(photoInputRef.current) photoInputRef.current.value = '';
            refreshData();
        } else {
            toast({ variant: 'destructive', title: "Error", description: result.message });
        }
    }

    async function handleDelete(observerId: string) {
        setIsDeleting(observerId);
        const result = await deleteObserver(observerId);
        if (result.success) {
            toast({ title: "Success", description: result.message });
            refreshData();
        } else {
             toast({ variant: 'destructive', title: "Error", description: result.message });
        }
        setIsDeleting(null);
    }
    
    const handleNextPage = () => {
        if (page < totalPages) {
            const newPage = page + 1;
            setPage(newPage);
            fetchObservers(newPage);
        }
    };
    
    const handlePrevPage = () => {
        if (page > 1) {
            const newPage = page - 1;
            setPage(newPage);
            fetchObservers(newPage);
        }
    };


    return (
        <div className="space-y-8">
            <h1 className="font-headline text-4xl font-bold text-primary">Observer Management</h1>
             <Card>
                <CardHeader>
                    <CardTitle>Add New Observer</CardTitle>
                    <CardDescription>Add a new observer to the system.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 max-w-2xl">
                             <FormField
                                control={form.control}
                                name="fullName"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Full Name</FormLabel>
                                        <FormControl>
                                            <Input placeholder="e.g. Jane Doe" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={form.control}
                                name="email"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Email Address</FormLabel>
                                        <FormControl>
                                            <Input type="email" placeholder="observer@example.com" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="password"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Password</FormLabel>
                                        <FormControl>
                                            <Input type="password" placeholder="••••••••" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="photo"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Photo</FormLabel>
                                    <FormControl>
                                        <div 
                                            className="flex items-center gap-4 cursor-pointer"
                                            onClick={() => photoInputRef.current?.click()}
                                        >
                                            {photoPreview ? (
                                            <Image
                                                src={photoPreview}
                                                alt="Photo preview"
                                                width={64}
                                                height={64}
                                                className="rounded-full object-cover aspect-square"
                                            />
                                            ) : (
                                            <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center border-2 border-dashed">
                                                <ImageIcon className="h-8 w-8 text-muted-foreground" />
                                            </div>
                                            )}
                                            <Input
                                                type="file"
                                                accept="image/*"
                                                ref={photoInputRef}
                                                className="hidden"
                                                onChange={(e) => {
                                                    const file = e.target.files?.[0];
                                                    if (file) {
                                                        setPhotoPreview(URL.createObjectURL(file));
                                                        field.onChange(file);
                                                    }
                                                }}
                                            />
                                            <span className="text-sm text-muted-foreground">Click to upload a photo</span>
                                        </div>
                                    </FormControl>
                                    <FormDescription>
                                        Upload a clear headshot of the observer.
                                    </FormDescription>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
                                Add Observer
                            </Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
            
            <Separator />

            <Card>
                <CardHeader>
                    <CardTitle>Current Observers ({totalObservers})</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="border rounded-md">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Name</TableHead>
                                <TableHead>Email</TableHead>
                                <TableHead className="text-right">Action</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading && (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center">
                                        <Loader2 className="mx-auto h-6 w-6 animate-spin text-primary" />
                                    </TableCell>
                                </TableRow>
                            )}
                            {!isLoading && observers.map(obs => (
                                <TableRow key={obs.id}>
                                    <TableCell className="font-medium flex items-center gap-3">
                                         <Image src={obs.photoURL} alt={obs.fullName} width={32} height={32} className="rounded-full object-cover" />
                                        {obs.fullName}
                                    </TableCell>
                                    <TableCell>{obs.email}</TableCell>
                                    <TableCell className="text-right">
                                        <AlertDialog>
                                            <AlertDialogTrigger asChild>
                                                 <Button variant="ghost" size="icon" disabled={!!isDeleting}>
                                                     {isDeleting === obs.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4 text-destructive" />}
                                                </Button>
                                            </AlertDialogTrigger>
                                            <AlertDialogContent>
                                                <AlertDialogHeader>
                                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                                <AlertDialogDescription>
                                                    This will permanently delete the observer and their account. This action cannot be undone.
                                                </AlertDialogDescription>
                                                </AlertDialogHeader>
                                                <AlertDialogFooter>
                                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                <AlertDialogAction onClick={() => handleDelete(obs.id)} className="bg-destructive hover:bg-destructive/90">
                                                    Delete
                                                </AlertDialogAction>
                                                </AlertDialogFooter>
                                            </AlertDialogContent>
                                        </AlertDialog>
                                    </TableCell>
                                </TableRow>
                            ))}
                            {!isLoading && observers?.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={3} className="text-center h-24">
                                        <div className="flex flex-col items-center gap-2 text-muted-foreground">
                                            <UserX className="h-8 w-8" />
                                            <span>No observers found.</span>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                    </div>
                     <div className="flex items-center justify-end space-x-2 py-4">
                        <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
                         <Button
                            variant="outline"
                            size="sm"
                            onClick={handlePrevPage}
                            disabled={page === 1}
                        >
                            <ChevronLeft className="h-4 w-4" />
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={handleNextPage}
                            disabled={page >= totalPages || observers.length < PAGE_SIZE}
                        >
                            Next
                            <ChevronRight className="h-4 w-4" />
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

export default function ObserverManagementPage() {
    const firestore = useFirestore();

    if (!firestore) {
        return (
            <div className="flex justify-center items-center h-full w-full p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="ml-2">Connecting to database...</span>
            </div>
        );
    }
    
    return <ObserverManagementComponent firestore={firestore} />;
}

    