'use client';

import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Vote, Users, Shield, ArrowRight, Settings, MessageSquare, Loader2 } from "lucide-react";
import { AnalyticsDashboard } from "@/app/(components)/analytics-dashboard";
import { useUser } from "@/firebase/provider";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

const managementPages = [
    {
        title: "Election Settings",
        description: "Configure election start and end times.",
        href: "/admin/settings",
        icon: Settings,
    },
    {
        title: "Contestant Management",
        description: "Add, remove, or update contestant information.",
        href: "/admin/contestants",
        icon: Vote,
    },
    {
        title: "Voter Management",
        description: "Manage the list of eligible voters and their details.",
        href: "/admin/voters",
        icon: Users,
    },
    {
        title: "Observer Management",
        description: "Manage observer accounts and permissions.",
        href: "/admin/observers",
        icon: Shield,
    },
    {
        title: "Chat Support",
        description: "Respond to voter queries in real-time.",
        href: "/admin/chat",
        icon: MessageSquare,
    },
];

export default function AdminDashboardPage() {
    const { user, isUserLoading } = useUser();
    const router = useRouter();

    useEffect(() => {
        if (!isUserLoading && !user) {
            router.replace('/admin/login');
        }
    }, [user, isUserLoading, router]);

    if (isUserLoading || !user) {
        return (
            <div className="flex h-full w-full items-center justify-center">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
        );
    }
    
    return (
        <div className="space-y-8">
            <div className="flex justify-between items-start">
                <div>
                    <h1 className="font-headline text-3xl md:text-4xl font-bold text-primary">Admin Dashboard</h1>
                    <p className="text-muted-foreground text-sm md:text-base">Welcome, Admin. Here's an overview of the election.</p>
                </div>
            </div>

            <AnalyticsDashboard />

            <div className="space-y-4">
                <h2 className="font-headline text-2xl font-semibold text-primary">Management Panels</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {managementPages.map((page) => {
                        const Icon = page.icon;
                        return (
                            <Card key={page.title} className="flex flex-col">
                                <CardHeader>
                                    <div className="flex items-start gap-4">
                                        <div className="bg-primary/10 text-primary p-3 rounded-lg">
                                            <Icon className="h-6 w-6" />
                                        </div>
                                        <div className="flex-1">
                                            <CardTitle className="font-headline text-lg md:text-xl">{page.title}</CardTitle>
                                            <CardDescription className="mt-1 text-xs md:text-sm">{page.description}</CardDescription>
                                        </div>
                                    </div>
                                </CardHeader>
                                <div className="flex-grow"/>
                                <CardContent className="pt-0">
                                    <Button asChild className="w-full">
                                        <Link href={page.href}>
                                            Manage <ArrowRight className="ml-2 h-4 w-4" />
                                        </Link>
                                    </Button>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}
