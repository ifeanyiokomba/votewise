
'use server';

import { getAdminApp, handleAdminError } from '@/firebase/admin';
import { revalidatePath } from 'next/cache';
import * as z from 'zod';
import { Timestamp } from 'firebase-admin/firestore';

const settingsSchema = z.object({
  startDateTime: z.string().datetime(),
  endDateTime: z.string().datetime(),
  isElectionActive: z.boolean(),
});

export async function saveElectionSettings(values: z.infer<typeof settingsSchema>) {
    const { startDateTime, endDateTime, isElectionActive } = values;

    try {
        const startDateUtc = new Date(startDateTime);
        const endDateUtc = new Date(endDateTime);

        if (endDateUtc <= startDateUtc) {
            return { success: false, message: 'Finish time must be after start time.' };
        }

        const dataToSave = {
            startDate: Timestamp.fromDate(startDateUtc),
            endDate: Timestamp.fromDate(endDateUtc),
            isElectionActive: isElectionActive,
        };
        
        const adminApp = await getAdminApp();
        const firestore = adminApp.firestore();
        
        await firestore.doc('settings/election').set(dataToSave, { merge: true });
        
        revalidatePath('/admin/settings');
        revalidatePath('/'); // Revalidate homepage
        revalidatePath('/vote/dashboard');

        return { success: true, message: 'Election settings saved successfully.' };
    } catch (error: any) {
        // Route the error through the centralized handler
        return handleAdminError(error, 'saving election settings');
    }
}
