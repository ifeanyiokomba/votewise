
'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon, Loader2, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatInTimeZone } from 'date-fns-tz';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { saveElectionSettings } from './actions';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const formSchema = z.object({
  electionDate: z.date({
    required_error: "An election date is required.",
  }),
  startTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (HH:MM)"),
  finishTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (HH:MM)"),
  isElectionActive: z.boolean().default(false),
});

interface ElectionSettingsData {
  startDate: { seconds: number; nanoseconds: number };
  endDate: { seconds: number; nanoseconds: number };
  isElectionActive?: boolean;
}

export function ElectionSettingsForm() {
  const { toast } = useToast();
  const firestore = useFirestore();
  const timeZone = 'Africa/Lagos';
  
  const electionSettingsRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return doc(firestore, 'settings', 'election');
  }, [firestore]);

  const { data: electionSettings, isLoading: isLoadingSettings } = useDoc<ElectionSettingsData>(electionSettingsRef);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
        startTime: '08:00',
        finishTime: '16:00',
        isElectionActive: false,
    }
  });

  useEffect(() => {
    if (electionSettings) {
        const valuesToReset: Partial<z.infer<typeof formSchema>> = {
          isElectionActive: electionSettings.isElectionActive ?? false,
        };

        if (electionSettings.startDate) {
            const startDateUtc = new Date(electionSettings.startDate.seconds * 1000);
            
            // This is the key change: create a Date object that represents the same wall-clock time as UTC, but in the local timezone.
            // formatInTimeZone correctly formats this.
            valuesToReset.electionDate = startDateUtc;
            valuesToReset.startTime = format(startDateUtc, 'HH:mm', { timeZone });
        }

        if (electionSettings.endDate) {
            const endDateUtc = new Date(electionSettings.endDate.seconds * 1000);
            valuesToReset.finishTime = format(endDateUtc, 'HH:mm', { timeZone });
        }
        
        form.reset(valuesToReset);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [electionSettings]);


  const { isSubmitting } = form.formState;

  async function onSubmit(values: z.infer<typeof formSchema>) {
    
    const { electionDate, startTime, finishTime, isElectionActive } = values;

    // Construct ISO strings that include the timezone offset for Africa/Lagos (+01:00)
    // This ensures that when the server parses them with `new Date()`, it creates the correct UTC time.
    const datePart = format(electionDate, 'yyyy-MM-dd');
    const startDateTimeString = `${datePart}T${startTime}:00`;
    const endDateTimeString = `${datePart}T${finishTime}:00`;


    const result = await saveElectionSettings({
      startDateTime: startDateTimeString,
      endDateTime: endDateTimeString,
      isElectionActive: isElectionActive
    });
    
    if (result.success) {
        toast({
            title: "Settings Saved",
            description: "Election settings have been updated successfully.",
        });
    } else {
        toast({
            variant: "destructive",
            title: "Save Failed",
            description: result.message || "Could not save election settings.",
        });
    }
  }

  if (isLoadingSettings) {
    return <div className="flex items-center space-x-2">
        <Loader2 className="h-5 w-5 animate-spin" />
        <span>Loading settings...</span>
    </div>;
  }
  
  const isElectionActive = form.watch('isElectionActive');
  const electionDate = form.watch('electionDate');
  const startTime = form.watch('startTime');

  const startDate = electionDate && startTime ? new Date(`${format(electionDate, 'yyyy-MM-dd')}T${startTime}`) : new Date();
  const isTimerStillCounting = new Date() < startDate;
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-lg">
        <FormField
          control={form.control}
          name="isElectionActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Election Status</FormLabel>
                <FormDescription>
                  Manually start or stop the election for all voters.
                </FormDescription>
              </div>
              <FormControl>
                <div className="flex items-center gap-4">
                    <span className={cn("font-bold", isElectionActive ? "text-green-500" : "text-destructive")}>
                        {isElectionActive ? "ACTIVE" : "STOPPED"}
                    </span>
                    <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                    />
                </div>
              </FormControl>
            </FormItem>
          )}
        />
        
         {isElectionActive && isTimerStillCounting && (
            <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Warning: Election is Active but Timer is Running</AlertTitle>
                <AlertDescription>
                    You have set the election to ACTIVE, but the countdown timer has not finished. Voters will be able to vote now. If this is not intended, set the status to STOPPED until the scheduled start time.
                </AlertDescription>
            </Alert>
        )}

        <div>
            <h3 className="text-lg font-medium mb-4 text-muted-foreground">Countdown Timer Settings</h3>
            <div className="space-y-8 pl-4 border-l-2">
                <FormField
                control={form.control}
                name="electionDate"
                render={({ field }) => (
                    <FormItem className="flex flex-col">
                    <FormLabel>Target Election Day</FormLabel>
                    <Popover>
                        <PopoverTrigger asChild>
                        <FormControl>
                            <Button
                            variant={"outline"}
                            className={cn(
                                "w-[240px] pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                            )}
                            >
                            {field.value ? (
                                format(field.value, "PPP")
                            ) : (
                                <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                        </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) =>
                            date < new Date(new Date().setHours(0,0,0,0))
                            }
                            initialFocus
                        />
                        </PopoverContent>
                    </Popover>
                    <FormMessage />
                    </FormItem>
                )}
                />

                <div className="flex gap-4">
                    <FormField
                    control={form.control}
                    name="startTime"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel>Target Start Time</FormLabel>
                        <FormControl>
                            <Input type="time" className="w-[180px]" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <FormField
                    control={form.control}
                    name="finishTime"
                    render={({ field }) => (
                        <FormItem className="flex flex-col">
                        <FormLabel>Target Finish Time</FormLabel>
                        <FormControl>
                            <Input type="time" className="w-[180px]" {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                </div>
            </div>
        </div>

        
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save Settings
        </Button>
      </form>
    </Form>
  );
}
