'use client';

import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ElectionSettingsForm } from "./election-settings-form";
import { useUser } from "@/firebase/provider";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Loader2 } from "lucide-react";

export default function ElectionSettingsPage() {
    const { user, isUserLoading } = useUser();
    const router = useRouter();

    useEffect(() => {
        if (!isUserLoading && !user) {
            router.replace('/admin/login');
        }
    }, [user, isUserLoading, router]);

    if (isUserLoading || !user) {
        return (
            <div className="flex h-full w-full items-center justify-center">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
        );
    }

    return (
        <div className="space-y-8">
            <h1 className="font-headline text-4xl font-bold text-primary">Election Settings</h1>
             <Card>
                <CardHeader>
                    <CardTitle>Configure Election</CardTitle>
                    <CardDescription>Set the day, start time, and finish time for the election. This will control the countdown timer on the homepage and enable/disable the voting process.</CardDescription>
                </CardHeader>
                <CardContent>
                    <ElectionSettingsForm />
                </CardContent>
            </Card>
        </div>
    );
}
