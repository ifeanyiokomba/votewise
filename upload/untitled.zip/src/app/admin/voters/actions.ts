
'use server';

import { getAdminApp } from '@/firebase/admin';
import { revalidatePath } from 'next/cache';
import Papa from 'papaparse';
import { z } from 'zod';


export const voterSchema = z.object({
  fullName: z.string().min(1, 'Full name is required.'),
  matricNumber: z.string().min(1, 'Matriculation number is required.'),
  department: z.string().min(1, 'Department is required.'),
  level: z.string().min(1, 'Level is required.'),
  email: z.string().email('Invalid email address.').optional().or(z.literal('')),
  phoneNumber: z.string().optional(),
  whatsappNumber: z.string().optional(),
});


export async function createVoter(
  data: z.infer<typeof voterSchema>
): Promise<{ success: boolean; message: string }> {
  try {
    const adminApp = await getAdminApp();
    const firestore = adminApp.firestore();
    
    const matricNumber = data.matricNumber.trim();
    const voterRef = firestore.collection('voters').doc(matricNumber);

    const existingDoc = await voterRef.get();
    if (existingDoc.exists) {
        return { success: false, message: `A voter with Matric Number ${matricNumber} already exists.` };
    }

    await voterRef.set({
        ...data,
        matricNumber, // ensure it's the trimmed version
        hasVoted: false,
    });

    revalidatePath('/admin/voters');
    return { success: true, message: 'Voter created successfully.' };

  } catch (error: any) {
    console.error("Error creating voter:", error);
    return { success: false, message: error.message || "An unexpected error occurred during voter creation." };
  }
}

export async function uploadVoters(
  csvContent: string
): Promise<{ success: boolean; message: string; count?: number }> {
    try {
        const adminApp = await getAdminApp();
        const firestore = adminApp.firestore();

        const parseResult = Papa.parse<Record<string, string>>(csvContent, {
            header: true,
            skipEmptyLines: true,
        });

        const voters = parseResult.data;
        const errors = parseResult.errors;

        if (errors.length > 0) {
            console.warn("CSV parsing errors found:", errors);
        }

        if (voters.length === 0) {
            return { success: false, message: 'CSV is empty or contains no valid data rows.' };
        }
        
        const batch = firestore.batch();
        let processedCount = 0;
        const requiredColumn = 'Matric Number/JAMB REG NO';

        for (const voter of voters) {
            const matricNumber = voter[requiredColumn]; 
            
            // Only process rows that have a valid, non-empty matriculation number.
            if (matricNumber && matricNumber.trim()) {
                const trimmedMatric = matricNumber.trim();
                
                const voterRef = firestore.collection('voters').doc(trimmedMatric);
                
                // Safely access and trim each property, providing a default empty string if undefined.
                const dataToSet = {
                    fullName: (voter.Name?.trim()) || '',
                    matricNumber: trimmedMatric,
                    department: (voter.Department?.trim()) || '',
                    level: (voter.Level?.trim()) || '',
                    email: (voter.Email?.trim()) || '',
                    phoneNumber: (voter['Phone Number']?.trim()) || '',
                    whatsappNumber: (voter['whatsapp number']?.trim()) || '',
                    hasVoted: false,
                };

                batch.set(voterRef, dataToSet, { merge: true });
                processedCount++;
            }
        }
        
        if (processedCount > 0) {
            await batch.commit();
        } else {
             return { success: false, message: `No valid voter data found to upload. Please check that the file has a "${requiredColumn}" column with valid data.` };
        }

        revalidatePath('/admin/voters');
        return { success: true, message: 'Voters uploaded successfully.', count: processedCount };
    } catch (error: any) {
        console.error("Error uploading voters:", error);
        // This now provides a more detailed error message for permission issues.
        if (error.code === 'permission-denied') {
            return { 
                success: false, 
                message: `Firestore Permission Denied: The current user does not have permission to write to the 'voters' collection. Please check Firestore security rules.`
            };
        }
        return { success: false, message: error.message || "An unexpected server error occurred during upload." };
    }
}


export async function deleteVoter(voterId: string): Promise<{ success: boolean; message: string }> {
    try {
        const adminApp = await getAdminApp();
        const firestore = adminApp.firestore();
        await firestore.collection('voters').doc(voterId).delete();
        revalidatePath('/admin/voters');
        return { success: true, message: 'Voter deleted successfully.' };
    } catch (error: any) {
        console.error('Error deleting voter:', error);
        return { success: false, message: error.message || 'An unexpected error occurred.' };
    }
}
    