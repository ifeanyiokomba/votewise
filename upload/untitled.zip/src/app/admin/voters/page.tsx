
'use client';
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Trash2, Upload, UserX, ChevronLeft, ChevronRight, UserPlus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { createVoter, deleteVoter, uploadVoters, voterSchema } from "./actions";
import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { query, orderBy, limit, startAfter, getDocs, collection, DocumentData, getCountFromServer, Firestore } from "firebase/firestore";
import { useFirestore } from "@/firebase";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { departments, levels } from "@/lib/data";

interface Voter {
    id: string;
    fullName: string;
    matricNumber: string;
    department: string;
    level: string;
    email: string;
    phoneNumber: string;
    whatsappNumber: string;
    _doc: DocumentData;
}

const PAGE_SIZE = 15;

function VoterManagementComponent({ firestore }: { firestore: Firestore }) {
    const { toast } = useToast();
    const [isDeleting, setIsDeleting] = useState<string | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    const [voters, setVoters] = useState<Voter[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [pageCursors, setPageCursors] = useState<(DocumentData | null)[]>([null]);
    const [totalVoters, setTotalVoters] = useState(0);

    const totalPages = useMemo(() => Math.ceil(totalVoters / PAGE_SIZE), [totalVoters]);

    const fetchTotalVoters = useCallback(async () => {
        try {
            const coll = collection(firestore, "voters");
            const snapshot = await getCountFromServer(coll);
            setTotalVoters(snapshot.data().count);
        } catch (error) {
            console.error("Error fetching total voters:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch total voter count.' });
        }
    }, [firestore, toast]);

    const fetchVoters = useCallback(async (pageNumber: number) => {
        setIsLoading(true);

        try {
            const votersCollection = collection(firestore, 'voters');
            let q;
            const lastVisible = pageCursors[pageNumber - 1];

            if (pageNumber > 1 && !lastVisible) {
                console.warn(`No cursor for page ${pageNumber}, fetching from start.`);
                setPage(1);
                setPageCursors([null]);
                q = query(votersCollection, orderBy('matricNumber'), limit(PAGE_SIZE));
            } else if (pageNumber > 1 && lastVisible) {
                q = query(votersCollection, orderBy('matricNumber'), startAfter(lastVisible), limit(PAGE_SIZE));
            } else {
                 q = query(votersCollection, orderBy('matricNumber'), limit(PAGE_SIZE));
            }
            
            const documentSnapshots = await getDocs(q);
            const newVoters = documentSnapshots.docs.map(doc => ({ id: doc.id, ...doc.data(), _doc: doc } as Voter));
            setVoters(newVoters);

            if (documentSnapshots.docs.length > 0) {
                const lastDoc = documentSnapshots.docs[documentSnapshots.docs.length - 1];
                if (pageNumber >= pageCursors.length) {
                    setPageCursors(prev => [...prev, lastDoc]);
                }
            }
        } catch (error) {
            console.error("Error fetching voters:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch voter data.' });
        } finally {
            setIsLoading(false);
        }
    }, [firestore, toast, pageCursors]);
    
    useEffect(() => {
        fetchTotalVoters();
        fetchVoters(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [firestore, fetchTotalVoters]);


    const form = useForm<z.infer<typeof voterSchema>>({
        resolver: zodResolver(voterSchema),
        defaultValues: {
            fullName: '',
            matricNumber: '',
            department: '',
            level: '',
            email: '',
            phoneNumber: '',
            whatsappNumber: ''
        },
    });

    const { formState: { isSubmitting: isCreatingVoter }, handleSubmit: handleCreateSubmit, control, reset } = form;

    async function onVoterCreateSubmit(values: z.infer<typeof voterSchema>) {
        try {
            const result = await createVoter(values);
            if (result.success) {
                toast({ title: 'Success', description: result.message });
                reset();
                await fetchTotalVoters();
                await fetchVoters(1); // Go back to first page to see new voter
                setPage(1);
                setPageCursors([null]);
            } else {
                toast({ variant: 'destructive', title: 'Error', description: result.message });
            }
        } catch (error) {
            console.error("Submit Error:", error);
            toast({ variant: 'destructive', title: 'Client Error', description: 'An unexpected error occurred on the client.' });
        }
    }

    const handleUpload = async () => {
        if (!fileInputRef.current?.files?.[0]) {
            toast({ variant: 'destructive', title: 'No File Selected', description: 'Please select a CSV file to upload.' });
            return;
        }
        
        const file = fileInputRef.current.files[0];
         if (file.type !== 'text/csv') {
          toast({ variant: 'destructive', title: 'Invalid File Type', description: 'Please upload a valid CSV file.' });
          return;
        }

        setIsUploading(true);
        const reader = new FileReader();

        reader.onload = async (e) => {
            const csvContent = e.target?.result as string;
            if (!csvContent) {
                setIsUploading(false);
                toast({ variant: 'destructive', title: "File Read Error", description: "Could not read the file content." });
                return;
            }
            
            try {
                toast({ title: 'Uploading...', description: 'Processing CSV file. This may take a moment.'});
                const result = await uploadVoters(csvContent);
                
                if (result.success) {
                    toast({ title: "Upload Successful", description: `${result.count} voters have been added or updated.` });
                    await fetchTotalVoters();
                    await fetchVoters(1);
                    setPage(1);
                    setPageCursors([null]);
                     if (fileInputRef.current) fileInputRef.current.value = ''; // Reset file input
                } else {
                    toast({ variant: 'destructive', title: "Upload Failed", description: result.message });
                }
            } catch (error) {
                 console.error("Upload Error:", error);
                 toast({ variant: 'destructive', title: 'Client Error', description: 'An unexpected error occurred during upload.' });
            } finally {
                setIsUploading(false);
            }
        };
        reader.onerror = () => {
            setIsUploading(false);
            toast({ variant: 'destructive', title: "File Read Error", description: "Could not read the selected file." });
        };
        reader.readAsText(file);
    };
    
     async function handleDelete(voterId: string) {
        setIsDeleting(voterId);
        try {
            const result = await deleteVoter(voterId);
            if (result.success) {
                toast({ title: "Success", description: result.message });
                await fetchTotalVoters();
                const newTotalPages = Math.ceil((totalVoters - 1) / PAGE_SIZE);
                if (page > newTotalPages && page > 1) {
                    const newPage = page - 1;
                    setPage(newPage);
                    fetchVoters(newPage);
                } else {
                    fetchVoters(page);
                }
            } else {
                 toast({ variant: 'destructive', title: "Error", description: result.message });
            }
        } catch (error) {
             console.error("Delete Error:", error);
             toast({ variant: 'destructive', title: 'Client Error', description: 'An unexpected error occurred on the client.' });
        } finally {
            setIsDeleting(null);
        }
    }

    const handleNextPage = () => {
        if (page < totalPages) {
            const newPage = page + 1;
            setPage(newPage);
            fetchVoters(newPage);
        }
    };

    const handlePrevPage = () => {
        if (page > 1) {
            const newPage = page - 1;
            setPage(newPage);
            fetchVoters(newPage);
        }
    };

    return (
        <div className="space-y-8">
            <h1 className="font-headline text-3xl md:text-4xl font-bold text-primary">Voter Management</h1>

            <Card>
                <CardHeader>
                    <CardTitle>Add Single Voter</CardTitle>
                    <CardDescription>Manually add a single voter to the system. This is the recommended method for individual entries.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form onSubmit={handleCreateSubmit(onVoterCreateSubmit)} className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <FormField control={control} name="fullName" render={({ field }) => (
                                    <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input placeholder="e.g. John Doe" {...field} /></FormControl><FormMessage /></FormItem>
                                )}/>
                                <FormField control={control} name="matricNumber" render={({ field }) => (
                                    <FormItem><FormLabel>Matric Number/JAMB REG NO</FormLabel><FormControl><Input placeholder="e.g. 2021/CS/20311" {...field} /></FormControl><FormMessage /></FormItem>
                                )}/>
                                <FormField control={control} name="department" render={({ field }) => (
                                    <FormItem><FormLabel>Department</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger></FormControl><SelectContent>{departments.map(d=><SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent></Select><FormMessage /></FormItem>
                                )}/>
                                <FormField control={control} name="level" render={({ field }) => (
                                    <FormItem><FormLabel>Level</FormLabel><Select onValueChange={field.onChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder="Select level" /></SelectTrigger></FormControl><SelectContent>{levels.map(l=><SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent></Select><FormMessage /></FormItem>
                                )}/>
                                <FormField control={control} name="email" render={({ field }) => (
                                    <FormItem><FormLabel>Email (Optional)</FormLabel><FormControl><Input type="email" placeholder="e.g. john.doe@example.com" {...field} /></FormControl><FormMessage /></FormItem>
                                )}/>
                                <FormField control={control} name="phoneNumber" render={({ field }) => (
                                    <FormItem><FormLabel>Phone Number (Optional)</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                                )}/>
                                <FormField control={control} name="whatsappNumber" render={({ field }) => (
                                    <FormItem className="md:col-span-2"><FormLabel>WhatsApp Number (Optional)</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                                )}/>
                            </div>
                            <Button type="submit" disabled={isCreatingVoter}>
                                {isCreatingVoter ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <UserPlus className="mr-2 h-4 w-4"/>}
                                Create Voter
                            </Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>

             <Card>
                <CardHeader>
                    <CardTitle>Upload Voter Data (CSV)</CardTitle>
                    <CardDescription>Upload a CSV file with voter data. Required columns: `Name`, `Matric Number/JAMB REG NO`, `Department`, `Level`. Optional: `Email`, `Phone Number`, `whatsapp number`.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex flex-col sm:flex-row items-end gap-4">
                        <div className="flex-grow w-full space-y-2">
                            <Label htmlFor="voter-file-input">Voter CSV File</Label>
                            <Input 
                                id="voter-file-input"
                                type="file" 
                                accept=".csv"
                                ref={fileInputRef}
                                disabled={isUploading}
                            />
                        </div>
                        <Button onClick={handleUpload} disabled={isUploading} className="w-full sm:w-auto">
                            {isUploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                            Upload
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Current Voters ({totalVoters})</CardTitle>
                    <CardDescription>List of all eligible voters in the database.</CardDescription>
                </CardHeader>
                <CardContent>
                     <div className="border rounded-md">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Name</TableHead>
                                    <TableHead>Matric No</TableHead>
                                    <TableHead className="hidden md:table-cell">Department</TableHead>
                                    <TableHead className="hidden lg:table-cell">Level</TableHead>
                                    <TableHead className="hidden xl:table-cell">Email</TableHead>
                                    <TableHead className="hidden xl:table-cell">Phone</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading && (
                                    <TableRow>
                                        <TableCell colSpan={7} className="text-center">
                                            <Loader2 className="mx-auto h-6 w-6 animate-spin text-primary" />
                                        </TableCell>
                                    </TableRow>
                                )}
                                {!isLoading && voters.map((voter) => (
                                    <TableRow key={voter.id}>
                                        <TableCell className="font-medium">{voter.fullName}</TableCell>
                                        <TableCell>{voter.matricNumber}</TableCell>
                                        <TableCell className="hidden md:table-cell">{voter.department}</TableCell>
                                        <TableCell className="hidden lg:table-cell">{voter.level}</TableCell>
                                        <TableCell className="hidden xl:table-cell">{voter.email}</TableCell>
                                        <TableCell className="hidden xl:table-cell">
                                            <div className="flex flex-col">
                                                <span>{voter.phoneNumber}</span>
                                                {voter.whatsappNumber && <span className="text-xs text-muted-foreground">WA: {voter.whatsappNumber}</span>}
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <AlertDialog>
                                                <AlertDialogTrigger asChild>
                                                    <Button variant="ghost" size="icon" disabled={isDeleting === voter.id}>
                                                        {isDeleting === voter.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4 text-destructive" />}
                                                    </Button>
                                                </AlertDialogTrigger>
                                                <AlertDialogContent>
                                                    <AlertDialogHeader>
                                                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                                    <AlertDialogDescription>
                                                        This action cannot be undone. This will permanently delete the voter record.
                                                    </AlertDialogDescription>
                                                    </AlertDialogHeader>
                                                    <AlertDialogFooter>
                                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                    <AlertDialogAction onClick={() => handleDelete(voter.id)} className="bg-destructive hover:bg-destructive/90">
                                                        Delete
                                                    </AlertDialogAction>
                                                    </AlertDialogFooter>
                                                </AlertDialogContent>
                                            </AlertDialog>
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {!isLoading && voters?.length === 0 && (
                                    <TableRow>
                                        <TableCell colSpan={7} className="h-24 text-center">
                                            <div className="flex flex-col items-center gap-2 text-muted-foreground">
                                                <UserX className="h-8 w-8" />
                                                <span>No voters found. Add one manually or upload a CSV to get started.</span>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                    <div className="flex items-center justify-end space-x-2 py-4">
                        <span className="text-sm text-muted-foreground">Page {page} of {totalPages}</span>
                         <Button
                            variant="outline"
                            size="sm"
                            onClick={handlePrevPage}
                            disabled={page === 1}
                        >
                            <ChevronLeft className="h-4 w-4" />
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={handleNextPage}
                            disabled={page >= totalPages || voters.length < PAGE_SIZE}
                        >
                            Next
                            <ChevronRight className="h-4 w-4" />
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}


export default function VoterManagementPage() {
    const firestore = useFirestore();

    if (!firestore) {
        return (
            <div className="flex justify-center items-center h-full w-full p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <span className="ml-2">Connecting to database...</span>
            </div>
        );
    }
    
    return <VoterManagementComponent firestore={firestore} />;
}
