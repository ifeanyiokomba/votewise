
'use client';

import { usePathname } from 'next/navigation';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import { Toaster } from '@/components/ui/toaster';
import { SiteFooter } from '@/components/site-footer';
import { AutomatedChatbot } from '@/components/chat/automated-chatbot';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isHomePage = pathname === '/';
  const isObserverPage = pathname.startsWith('/observer');
  const isAdminPage = pathname.startsWith('/admin');

  // Determine if the chatbot should be shown.
  // It should NOT be shown on the homepage, any admin pages, or any observer pages.
  const showChatbot = !isHomePage && !isAdminPage && !isObserverPage;

  return (
    <FirebaseClientProvider>
        <div className="flex-1 flex flex-col">
            {children}
        </div>
        {showChatbot && <AutomatedChatbot />}
        <SiteFooter />
        <Toaster />
    </FirebaseClientProvider>
  );
}
