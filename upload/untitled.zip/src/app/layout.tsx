
import type { Metadata } from 'next';
import './globals.css';
import { cn } from '@/lib/utils';
import { Inter, Space_Grotesk } from 'next/font/google';
import { AppProvider } from './app-provider';
import Link from 'next/link';
import { BrandLogo } from '@/components/brand-logo';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-space-grotesk' });

export const metadata: Metadata = {
  title: 'Okomba Elections',
  description: 'A professional web application for elections.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn('font-body antialiased min-h-screen flex flex-col', inter.variable, spaceGrotesk.variable)}>
        <AppProvider>
          <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-sm border-b">
              <div className="container mx-auto px-4 md:px-6 flex h-16 items-center justify-between">
                  <a href="https://www.okomba.com" target="_blank" rel="noopener noreferrer" aria-label="Okomba Website">
                      <BrandLogo className="h-10 w-auto" />
                  </a>
                  <div className="flex items-center gap-2">
                     <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" asChild>
                            <Link href="/observer/login">
                              <Eye className="h-5 w-5" />
                              <span className="sr-only">Observer Login</span>
                            </Link>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Observer Login</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
              </div>
            </header>
          {children}
        </AppProvider>
      </body>
    </html>
  );
}
