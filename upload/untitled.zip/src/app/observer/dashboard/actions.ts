
'use server';

import { getAdminApp } from '@/firebase/admin';
import { FieldValue } from 'firebase-admin/firestore';

interface ObserverAction {
    userId: string;
    userName: string;
    userRole: 'observer';
}

interface ActionResult {
    success: boolean;
    message: string;
}

async function logObserverActivity(action: string, details: Record<string, any>, actor: ObserverAction) {
    const adminApp = await getAdminApp();
    const firestore = adminApp.firestore();
    
    await firestore.collection('auditLogs').add({
        userId: actor.userId,
        userName: actor.userName,
        userRole: actor.userRole,
        action: action,
        details: details,
        timestamp: FieldValue.serverTimestamp(),
    });
}


export async function findVoterStatus(
    matricNumber: string,
    actor: ObserverAction
): Promise<ActionResult> {
    try {
        const adminApp = await getAdminApp();
        const firestore = adminApp.firestore();
        const voterRef = firestore.collection('voters').doc(matricNumber);
        const voterDoc = await voterRef.get();

        let message;
        if (!voterDoc.exists) {
            message = `Voter with Matric Number '${matricNumber}' was not found in the database.`;
        } else {
            const voterData = voterDoc.data();
            const status = voterData?.hasVoted ? 'has already voted' : 'has not voted yet';
            message = `Voter '${voterData?.fullName}' (${matricNumber}) found and ${status}.`;
        }

        await logObserverActivity('Searched for Voter Status', { matricNumber }, actor);

        return { success: true, message: message };

    } catch (error: any) {
        console.error("Error finding voter status:", error);
        return { success: false, message: "An unexpected server error occurred." };
    }
}


export async function resendVoterOtvp(
    matricNumber: string,
    voterName: string,
    channel: 'Email' | 'WhatsApp' | 'SMS',
    actor: ObserverAction
): Promise<ActionResult> {
    try {
        // In a real application, this would integrate with an email/SMS/WhatsApp gateway
        // to send a new One-Time Verification PIN (OTVP).
        // For this demo, we will just simulate the action and log it.
        
        console.log(`Simulating OTVP resend to ${voterName} via ${channel}`);

        await logObserverActivity(
            'Resent OTVP for Voter', 
            { matricNumber: matricNumber, voterName: voterName, channel: channel },
            actor
        );
        
        return { 
            success: true, 
            message: `A new OTVP has been sent to ${voterName} via ${channel}.`
        };

    } catch (error: any) {
        console.error("Error resending OTVP:", error);
        return { success: false, message: "An unexpected server error occurred while resending the OTVP." };
    }
}
