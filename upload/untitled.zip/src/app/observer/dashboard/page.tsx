
'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, KeyRound, Mail, MessageSquare, Smartphone, Loader2, Info, Ticket } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { VoterActivityAnalytics } from './voter-activity-analytics';
import { UserNav } from '@/app/admin/user-nav';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AdminChatConsole } from "@/components/chat/admin-chat-console";
import { useUser } from '@/firebase';
import { useRouter } from 'next/navigation';
import { findVoterStatus, resendVoterOtvp } from './actions';


export default function ObserverDashboardPage() {
  const { toast } = useToast();
  const [selectedVoter, setSelectedVoter] = useState<{name: string, matric: string} | null>(null);
  const [isResendPopoverOpen, setIsResendPopoverOpen] = useState(false);
  const [sendingMethod, setSendingMethod] = useState<'Email' | 'WhatsApp' | 'SMS' | null>(null);
  const [searchMatric, setSearchMatric] = useState('');
  const [isSearching, setIsSearching] = useState(false);

  const { user, isUserLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.replace('/observer/login');
    }
  }, [user, isUserLoading, router]);

  
  const handleOpenResendPopover = (voter: {name: string, matric: string}) => {
    setSelectedVoter(voter);
    setIsResendPopoverOpen(true);
  };
  
  const handleResendOtvp = async (method: 'Email' | 'WhatsApp' | 'SMS') => {
    if (!selectedVoter || !user) return;

    setSendingMethod(method);
    
    const actor = { userId: user.uid, userName: user.displayName || 'Observer', userRole: 'observer' as const };
    const result = await resendVoterOtvp(selectedVoter.matric, selectedVoter.name, method, actor);
    
    toast({
        title: result.success ? "OTVP Sent" : "Action Failed",
        description: result.message,
        variant: result.success ? "default" : "destructive",
    });

    setSendingMethod(null);
    setIsResendPopoverOpen(false);
    setSelectedVoter(null);
  };

  const handleFindVoter = async () => {
    if (!searchMatric.trim() || !user) return;
    setIsSearching(true);
    
    const actor = { userId: user.uid, userName: user.displayName || 'Observer', userRole: 'observer' as const };
    const result = await findVoterStatus(searchMatric.trim(), actor);
    
    toast({
        title: result.success ? "Search Complete" : "Search Failed",
        description: result.message,
    });

    setIsSearching(false);
  }

  if (isUserLoading || !user) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="flex h-screen bg-secondary/40 overflow-hidden">
      <main className="flex-1 flex flex-col overflow-y-auto relative">
        <header className="flex h-16 items-center justify-between border-b bg-background/95 px-4 md:px-6 sticky top-0 z-30">
            <div>
                <h1 className="font-headline text-2xl md:text-3xl font-bold text-primary">Observer Dashboard</h1>
                <p className="text-muted-foreground text-sm hidden md:block">Real-time election monitoring and management tools.</p>
            </div>
            <UserNav />
        </header>
        
        <div className="flex-1 p-4 md:p-6 lg:p-8 space-y-6">
            <Alert variant="destructive">
              <Info className="h-4 w-4" />
              <AlertTitle>Security Notice</AlertTitle>
              <AlertDescription>
                You are in a privileged access area. All actions performed on this dashboard are logged and audited.
              </AlertDescription>
            </Alert>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-3 xl:col-span-2 flex flex-col gap-6">
                    <VoterActivityAnalytics />
                </div>

                <div className="lg:col-span-3 xl:col-span-1 flex flex-col gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-xl">
                            <KeyRound />
                            Voter Tools
                            </CardTitle>
                            <CardDescription>Manually assist voters or check registration.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <label className="text-sm font-medium">Find Voter Status</label>
                                <div className="flex gap-2">
                                    <Input 
                                        placeholder="Enter Matric Number..." 
                                        value={searchMatric}
                                        onChange={(e) => setSearchMatric(e.target.value)}
                                        disabled={isSearching}
                                    />
                                    <Button onClick={handleFindVoter} disabled={isSearching || !searchMatric.trim()}>
                                        {isSearching ? <Loader2 className="h-4 w-4 animate-spin"/> : <Search className="h-4 w-4" />}
                                    </Button>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <label className="text-sm font-medium">Resend OTVP</label>
                                 <Popover open={isResendPopoverOpen} onOpenChange={setIsResendPopoverOpen}>
                                    <PopoverTrigger asChild>
                                        <Button className="w-full" variant="outline" onClick={() => handleOpenResendPopover({name: 'Mock Voter', matric: '2024/XX/12345'})}>
                                            <Mail className="mr-2 h-4 w-4" /> Resend OTVP for a Voter
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-80">
                                        <div className="grid gap-4">
                                            <div className="space-y-2">
                                                <h4 className="font-medium leading-none">Resend OTVP for {selectedVoter?.name}</h4>
                                                <p className="text-sm text-muted-foreground">
                                                    Select the channel to send the new PIN. This action will be logged.
                                                </p>
                                            </div>
                                            <div className="flex flex-col space-y-3 pt-4">
                                                <Button onClick={() => handleResendOtvp('Email')} disabled={!!sendingMethod}>
                                                    {sendingMethod === 'Email' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Mail className="mr-2 h-4 w-4" />} Send via Email
                                                </Button>
                                                <Button onClick={() => handleResendOtvp('WhatsApp')} disabled={!!sendingMethod}>
                                                    {sendingMethod === 'WhatsApp' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <MessageSquare className="mr-2 h-4 w-4" />} Send via WhatsApp
                                                </Button>
                                                <Button onClick={() => handleResendOtvp('SMS')} disabled={!!sendingMethod}>
                                                    {sendingMethod === 'SMS' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Smartphone className="mr-2 h-4 w-4" />} Send via SMS
                                                </Button>
                                            </div>
                                        </div>
                                    </PopoverContent>
                                </Popover>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
             <Card className="h-[calc(100vh-320px)] flex flex-col">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Ticket />
                        Voter Support Tickets
                    </CardTitle>
                    <CardDescription>Voter-submitted issues. Select a ticket to see details.</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                    <AdminChatConsole />
                </CardContent>
            </Card>
        </div>
      </main>
    </div>
  );
}
