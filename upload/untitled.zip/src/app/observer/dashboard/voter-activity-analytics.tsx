
'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuCheckboxItem } from '@/components/ui/dropdown-menu';
import { Search, FileDown, ListFilter, Clock } from 'lucide-react';
import { mockVoterActivity } from '@/lib/data';
import { Badge } from '@/components/ui/badge';
import { format, parseISO } from 'date-fns';
import { useState } from 'react';

const statusStyles: {[key: string]: string} = {
    'Voted': 'bg-green-100 text-green-800 border-green-200',
    'Pending OTP': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    'In Progress': 'bg-blue-100 text-blue-800 border-blue-200',
    'Logged In': 'bg-gray-100 text-gray-800 border-gray-200',
}

export function VoterActivityAnalytics() {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredActivity = mockVoterActivity.filter(activity => 
    activity.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    activity.matric.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatTime = (time: string | null) => {
      if (!time) return <span className="text-muted-foreground">-</span>;
      return format(parseISO(time), 'HH:mm:ss');
  }

  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                 <CardTitle className="text-xl">Voter Activity</CardTitle>
                <CardDescription>Real-time monitoring of all voter interactions.</CardDescription>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
                 <div className="relative flex-1 sm:flex-initial">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                        type="search" 
                        placeholder="Search by name or matric..." 
                        className="pl-8 w-full sm:w-[250px] lg:w-[300px]"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm" className="h-9 gap-1">
                            <ListFilter className="h-3.5 w-3.5" />
                            <span className="sr-only sm:not-sr-only sm:whitespace-nowrap">Filter</span>
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Filter by status</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        {Object.keys(statusStyles).map(status => (
                             <DropdownMenuCheckboxItem key={status} checked>{status}</DropdownMenuCheckboxItem>
                        ))}
                    </DropdownMenuContent>
                </DropdownMenu>
                <Button size="sm" variant="outline" className="h-9 gap-1">
                    <FileDown className="h-3.5 w-3.5" />
                    <span className="sr-only sm:not-sr-only sm:whitespace-nowrap">Export</span>
                </Button>
            </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto">
        <div className="border rounded-md">
            <Table>
            <TableHeader className="sticky top-0 bg-secondary">
                <TableRow>
                    <TableHead>Voter</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-center">
                        <div className="flex items-center justify-center gap-1">
                            <Clock className="h-4 w-4" />
                            Timestamps
                        </div>
                    </TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {filteredActivity.length > 0 ? (
                    filteredActivity.map((activity) => (
                        <TableRow key={activity.id}>
                            <TableCell>
                                <div className="font-medium">{activity.name}</div>
                                <div className="text-sm text-muted-foreground">{activity.matric}</div>
                            </TableCell>
                             <TableCell>
                                <div>{activity.department}</div>
                                <div className="text-sm text-muted-foreground">{activity.level}</div>
                            </TableCell>
                            <TableCell>
                                <Badge variant="outline" className={statusStyles[activity.status]}>{activity.status}</Badge>
                            </TableCell>
                            <TableCell className="text-center text-xs space-y-1">
                                <p><strong>Login:</strong> {formatTime(activity.loginTime)}</p>
                                <p><strong>OTP:</strong> {formatTime(activity.otpSendTime)}</p>
                                <p><strong>Vote:</strong> {formatTime(activity.voteTime)}</p>
                            </TableCell>
                        </TableRow>
                    ))
                ) : (
                    <TableRow>
                        <TableCell colSpan={4} className="h-24 text-center">
                            No matching voter activity found.
                        </TableCell>
                    </TableRow>
                )}
            </TableBody>
            </Table>
        </div>
      </CardContent>
    </Card>
  );
}
