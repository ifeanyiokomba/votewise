
'use client';

// This layout component no longer needs to perform authentication checks.
// It simply renders the child components.
export default function ObserverLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
