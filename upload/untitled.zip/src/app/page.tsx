
import { HomePageClient } from './(home)/home-page-client';

export default function Home() {
  return (
    <main className="flex-1 bg-background text-foreground">
      <div className="relative overflow-hidden">
         <div 
          className="absolute top-0 left-0 w-full h-full bg-cover bg-center -z-20" 
          style={{backgroundImage: 'radial-gradient(circle at 1px 1px, hsl(var(--secondary)) 1px, transparent 0)' , backgroundSize: '2rem 2rem'}}
        />
        
        <div className="container mx-auto px-4 md:px-6">
          <HomePageClient />
        </div>
      </div>
    </main>
  );
}
