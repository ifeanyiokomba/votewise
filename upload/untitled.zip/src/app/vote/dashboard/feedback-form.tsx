
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

export function FeedbackForm({ onSubmit }: { onSubmit: () => void }) {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const router = useRouter();


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if(rating === 0) {
        toast({
            variant: 'destructive',
            title: "Rating Required",
            description: "Please select a star rating before submitting."
        });
        return;
    }
    setIsSubmitting(true);
    // Simulate API call to save feedback
    await new Promise(res => setTimeout(res, 1500));
    console.log('Feedback submitted:', { rating, comment });
    setIsSubmitting(false);
    onSubmit();
  };
  
  const handleSkip = () => {
    onSubmit();
    router.push('/');
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <label className="text-sm font-medium text-center block">How would you rate your voting experience?</label>
        <div className="flex justify-center space-x-1">
          {[1, 2, 3, 4, 5].map(star => (
            <button
              type="button"
              key={star}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(star)}
              className="p-1"
            >
              <Star
                className={cn(
                  'h-8 w-8 cursor-pointer transition-all',
                  (hoverRating || rating) >= star
                    ? 'text-yellow-400 fill-yellow-400'
                    : 'text-gray-300 hover:text-yellow-300'
                )}
              />
            </button>
          ))}
        </div>
      </div>
      <div className="space-y-2">
        <label htmlFor="comment" className="text-sm font-medium">
          Do you have any comments for us? (Optional)
        </label>
        <Textarea
          id="comment"
          placeholder="Tell us what you liked or what could be improved..."
          value={comment}
          onChange={e => setComment(e.target.value)}
        />
      </div>
       <div className="flex flex-col sm:flex-row gap-2">
            <Button type="button" variant="outline" onClick={handleSkip} className="w-full">
                Skip
            </Button>
            <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Submit Feedback
            </Button>
      </div>
    </form>
  );
}
