
'use client';

import { useState, memo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { contestants } from '@/lib/data';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { CheckCircle, Loader2, Vote as VoteIcon, ArrowRight, BarChart3, AlertTriangle } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from '@/components/ui/dialog';
import { useFirebase, useUser, useDoc, useMemoFirebase } from '@/firebase';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { doc, getDoc } from 'firebase/firestore';
import { RealtimeResults } from '@/app/(home)/realtime-results';
import { Alert, AlertTitle } from '@/components/ui/alert';


type Selections = {
  [position: string]: string | null; // contestant id
};

type Contestant = {
  id: string;
  name: string;
  department: string;
  photoUrl: string;
  phrase: string;
};

interface ElectionSettings {
  startDate: { seconds: number; nanoseconds: number };
  endDate: { seconds: number; nanoseconds: number };
  isElectionActive?: boolean;
}

const ContestantCard = memo(({
  contestant,
  isSelected,
  onSelect,
  disabled
}: {
  contestant: Contestant;
  isSelected: boolean;
  onSelect: () => void;
  disabled: boolean;
}) => (
  <div
    className={cn(
      'relative rounded-lg border bg-card text-card-foreground shadow-sm transition-all duration-200 overflow-hidden group',
      !disabled && 'cursor-pointer hover:shadow-lg hover:border-primary',
      isSelected && 'ring-2 ring-primary ring-offset-2 border-primary',
      disabled && 'opacity-60 cursor-not-allowed'
    )}
    onClick={!disabled ? onSelect : undefined}
  >
    {isSelected && (
        <div className="absolute top-2 right-2 z-10 bg-white rounded-full p-0.5">
          <CheckCircle className="h-6 w-6 text-primary fill-white" />
        </div>
    )}
    <div className={cn("p-4 flex flex-col items-center text-center relative")}>
      <Image
        src={contestant.photoUrl}
        alt={`Photo of ${contestant.name}`}
        width={120}
        height={120}
        data-ai-hint="portrait"
        className="rounded-full mb-4 aspect-square object-cover border-4 border-transparent group-hover:border-primary/20 transition-colors"
      />
      <p className="font-semibold text-lg">{contestant.name}</p>
       <p className="text-xs text-muted-foreground mt-1">{contestant.department}</p>
      
      <p className="text-sm mt-3 font-medium text-primary h-10 flex items-center">"{contestant.phrase}"</p>
    </div>
  </div>
));
ContestantCard.displayName = 'ContestantCard';


export default function VotingDashboardPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user } = useUser();
  const { firebaseApp, firestore } = useFirebase();
  const [selections, setSelections] = useState<Selections>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showResultsPreview, setShowResultsPreview] = useState(false);
  const [matricNumber, setMatricNumber] = useState<string | null>(null);

  const electionSettingsRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return doc(firestore, 'settings', 'election');
  }, [firestore]);

  const { data: electionSettings, isLoading: isLoadingSettings } = useDoc<ElectionSettings>(electionSettingsRef);
  
  const isVotingActive = useMemo(() => electionSettings?.isElectionActive ?? false, [electionSettings]);
  const isVotingDisabled = isLoadingSettings || !isVotingActive;

   useEffect(() => {
    let timer: NodeJS.Timeout;
    if (showResultsPreview) {
      timer = setTimeout(() => {
        router.push('/');
      }, 10000);
    }
    return () => clearTimeout(timer);
  }, [showResultsPreview, router]);

  useEffect(() => {
    async function fetchMatricNumber() {
      if (user && firestore) {
        const sessionRef = doc(firestore, 'sessions', user.uid);
        const sessionDoc = await getDoc(sessionRef);
        if (sessionDoc.exists()) {
          setMatricNumber(sessionDoc.data().matricNumber);
        } else {
            toast({ variant: 'destructive', title: "Session Error", description: "Could not retrieve your voting session. Please verify again." });
            router.push('/vote/verify');
        }
      }
    }
    fetchMatricNumber();
  }, [user, firestore, router, toast]);


  const handleSelect = (position: string, contestantId: string) => {
    if (isVotingDisabled) return;
    setSelections(prev => ({ ...prev, [position]: contestantId }));
  };
  
  const getSelectedCandidate = (position: string) => {
    const contestantId = selections[position];
    if (!contestantId) return null;
    return contestants[position as keyof typeof contestants].find(c => c.id === contestantId);
  }

  const handleCastVote = () => {
    if (isLoadingSettings) return;

    if (!isVotingActive) {
        toast({ variant: 'destructive', title: 'Voting Not Active', description: 'The election is not currently active. Please try again later.' });
        return;
    }

    const hasVotedForAll = Object.keys(contestants).every(pos => selections[pos]);
    if (!hasVotedForAll) {
        toast({
            variant: 'destructive',
            title: 'Incomplete Vote',
            description: 'Please select a candidate for every position before proceeding.',
        });
        return;
    }
    setShowConfirmation(true);
  }

  const handleFinalVote = async () => {
    setShowConfirmation(false);
    setIsSubmitting(true);
    
    if (!user || !firebaseApp || !matricNumber) {
        toast({ variant: 'destructive', title: "Authentication Error", description: "Your voting session is invalid. Please re-verify." });
        setIsSubmitting(false);
        return;
    }

    try {
        const functions = getFunctions(firebaseApp);
        const castVote = httpsCallable(functions, 'castVote');
        
        await castVote({ selections, matricNumber });

        setIsSubmitting(false);
        toast({
            title: "Vote Cast Successfully!",
            description: "Thank you for participating in the election."
        });

        setShowResultsPreview(true);

    } catch (e: any) {
        console.error("Vote submission failed: ", e);
        let description = "Could not submit your vote. Please try again.";
        if (e.code === 'functions/failed-precondition') {
            description = "It looks like you have already voted.";
        }
        toast({ variant: 'destructive', title: "Error", description });
        setIsSubmitting(false);
    }
  };

  return (
    <main className="flex-1 bg-secondary/30 py-8 md:py-12">
      <div className="container mx-auto px-4">
        <Card className="max-w-5xl mx-auto shadow-2xl border-0">
          <CardHeader className="text-center bg-background rounded-t-lg border-b">
            <CardTitle className="font-headline text-4xl text-primary">Voting Ballot</CardTitle>
            <CardDescription>Your voice matters. Select one candidate for each position.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-12 p-4 md:p-8">
            {isVotingDisabled && (
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>
                        {isLoadingSettings ? 'Loading election status...' : 'Voting is currently closed.'}
                    </AlertTitle>
                </Alert>
            )}
            {Object.entries(contestants).map(([position, candidates]) => (
              <div key={position}>
                <h3 className="font-headline text-3xl font-bold mb-6 border-b-2 border-primary/20 pb-3 text-foreground">{position}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {candidates.map(candidate => (
                    <ContestantCard
                      key={candidate.id}
                      contestant={candidate}
                      isSelected={selections[position] === candidate.id}
                      onSelect={() => handleSelect(position, candidate.id)}
                      disabled={isVotingDisabled}
                    />
                  ))}
                </div>
              </div>
            ))}
            <div className="pt-8 flex justify-center border-t border-dashed mt-12">
              <Button size="lg" onClick={handleCastVote} disabled={isSubmitting || isVotingDisabled} className="h-14 px-16 text-lg shadow-lg transform hover:scale-105 transition-transform">
                {isSubmitting || isLoadingSettings || !matricNumber ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  <VoteIcon className="mr-3 h-6 w-6" />
                )}
                Cast Your Vote
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-headline text-2xl">Confirm Your Selections</AlertDialogTitle>
            <AlertDialogDescription>
              Please review your choices. Once submitted, your vote cannot be changed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4 max-h-60 overflow-y-auto pr-4 my-4">
            {Object.keys(selections).map(position => {
              const candidate = getSelectedCandidate(position);
              return (
                <div key={position} className="flex items-center justify-between text-base p-3 bg-secondary rounded-md">
                  <span className="font-semibold text-muted-foreground">{position}:</span>
                  <div className="flex items-center gap-2 font-bold text-primary">
                    <span>{candidate?.name}</span>
                    <ArrowRight className="h-4 w-4"/>
                  </div>
                </div>
              );
            })}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Go Back & Edit</AlertDialogCancel>
            <AlertDialogAction onClick={handleFinalVote} className="bg-primary hover:bg-primary/90">
              Confirm & Vote
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showResultsPreview} onOpenChange={(isOpen) => { if(!isOpen) router.push('/') }}>
        <DialogContent>
          <DialogHeader>
            <div className="flex items-center justify-center gap-2">
                <BarChart3 className="h-6 w-6 text-primary"/>
                <DialogTitle className="font-headline text-2xl text-center">Live Election Results</DialogTitle>
            </div>
            <DialogDescription className="text-center pt-2">
                Here's a quick look at the current results. You will be redirected shortly.
            </DialogDescription>
          </DialogHeader>
          <div className="p-4">
            <RealtimeResults />
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
