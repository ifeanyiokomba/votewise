
'use server';

import * as z from 'zod';
import { getAdminApp } from '@/firebase/admin';

const formSchema = z.object({
  matricNumber: z.string().min(1, 'Matric number is required.'),
  department: z.string({ required_error: 'Please select a department.' }),
  level: z.string({ required_error: 'Please select your level.' }),
});

interface VerificationResult {
  success: boolean;
  message: string;
  voter?: {
    fullName: string;
    department: string;
    level: string;
    email: string;
    phone: string;
    whatsapp: string;
  };
}

export async function verifyStudent(
  data: z.infer<typeof formSchema>
): Promise<VerificationResult> {
  try {
    const firestore = getAdminApp().firestore();
    const votersRef = firestore.collection('voters');

    const matricNumber = data.matricNumber.trim();
    
    console.log('Verifying student:', data);
    
    const snapshot = await votersRef
      .where('matricNumber', '==', matricNumber)
      .where('department', '==', data.department)
      .where('level', '==', data.level)
      .limit(1)
      .get();
      
    if (snapshot.empty) {
      console.log(`Verification failed: No voter found with matric number ${matricNumber}`);
      return { success: false, message: 'Voter not found. Please check your details or contact support.' };
    }

    const voterDoc = snapshot.docs[0].data();

    // Prevent re-voting by checking the hasVoted flag
    if (voterDoc.hasVoted) {
      return { success: false, message: 'This voter has already cast their vote.' };
    }

    console.log(`Verification successful for ${voterDoc.fullName}`);

    return { 
      success: true, 
      message: 'Verification successful!',
      voter: {
        fullName: voterDoc.fullName,
        department: voterDoc.department,
        level: voterDoc.level,
        email: voterDoc.email,
        phone: voterDoc.phoneNumber,
        whatsapp: voterDoc.whatsappNumber,
      }
    };
  } catch (error) {
    console.error("Error during student verification:", error);
    return { success: false, message: 'An unexpected server error occurred.' };
  }
}
