
'use client';

import { useState, useEffect, memo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { departments, levels } from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Loader2, ShieldCheck, UserCheck, Mail, MessageSquare, Smartphone, KeyRound } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { verifyStudent } from './actions';
import { maskString } from '@/lib/utils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useAuth, useFirestore, useUser } from '@/firebase';
import { signInAnonymously } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

const verifySchema = z.object({
  matricNumber: z.string().min(1, 'Matric number is required.'),
  department: z.string({ required_error: 'Please select a department.' }),
  level: z.string({ required_error: 'Please select your level.' }),
});

type VerifyStep = 'verifying' | 'confirmation' | 'enteringOtvp';
type OtvpMethod = 'Email' | 'WhatsApp' | 'SMS';

type VoterDetails = {
    fullName: string;
    department: string;
    level: string;
    email: string;
    phone: string;
    whatsapp: string;
}

const VoterDetail = memo(({ label, value }: { label: string; value: string }) => (
    <div className="flex justify-between py-2 border-b border-dashed">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className="text-sm font-medium">{value}</span>
    </div>
));
VoterDetail.displayName = 'VoterDetail';


export default function VoterVerificationPage() {
    const router = useRouter();
    const { toast } = useToast();
    const auth = useAuth();
    const firestore = useFirestore();
    const [step, setStep] = useState<VerifyStep>('verifying');
    const [voterDetails, setVoterDetails] = useState<VoterDetails | null>(null);
    const [selectedMethod, setSelectedMethod] = useState<OtvpMethod | null>(null);
    const [timer, setTimer] = useState(60);
    const [sendingMethod, setSendingMethod] = useState<OtvpMethod | null>(null);
    const [isVerifyingOtvp, setIsVerifyingOtvp] = useState(false);
    const [otvp, setOtvp] = useState('');
    
    const form = useForm<z.infer<typeof verifySchema>>({
        resolver: zodResolver(verifySchema),
        defaultValues: {
            matricNumber: '',
        },
    });

    const { getValues } = form;
    const { isSubmitting } = form.formState;

    useEffect(() => {
        let interval: NodeJS.Timeout;
        if (step === 'enteringOtvp' && timer > 0) {
            interval = setInterval(() => {
                setTimer(prev => prev - 1);
            }, 1000);
        }
        return () => clearInterval(interval);
    }, [step, timer]);

    async function onVerifySubmit(values: z.infer<typeof verifySchema>) {
        const result = await verifyStudent(values);

        if (result.success && result.voter) {
            setVoterDetails(result.voter);
            setStep('confirmation');
        } else {
            toast({
                variant: 'destructive',
                title: "Verification Failed",
                description: result.message,
            });
        }
    }

    const handleSendOtvp = async (method: OtvpMethod) => {
        setSendingMethod(method);
        // Simulate API call to send OTVP
        await new Promise(resolve => setTimeout(resolve, 1500));
        setSendingMethod(null);
        setSelectedMethod(method);
        setStep('enteringOtvp');
        setTimer(60);
        toast({
            title: 'OTVP Sent!',
            description: `A One-Time Verification PIN has been sent to your ${method}.`,
        });
    };
    
    const handleVerifyOtvp = async () => {
        if (!auth || !firestore) {
             toast({ variant: 'destructive', title: 'Authentication Error', description: 'Firebase service is not available.' });
            return;
        }
        if (otvp.length !== 6) {
            toast({ variant: 'destructive', title: 'Invalid PIN', description: 'OTVP must be 6 digits.' });
            return;
        }
        setIsVerifyingOtvp(true);
        // Simulate OTVP verification. In a real app, you'd call a server function.
        // For this demo, we'll assume '123456' is the correct PIN.
        if (otvp !== '123456') {
             await new Promise(resolve => setTimeout(resolve, 1000));
             toast({ variant: 'destructive', title: 'Invalid PIN', description: 'The OTVP you entered is incorrect.' });
             setIsVerifyingOtvp(false);
             return;
        }
        
        try {
            // Sign in anonymously to create a temporary user session
            const userCredential = await signInAnonymously(auth);
            const user = userCredential.user;

            const verifiedData = getValues();
            // Store the verified matric number with the anonymous UID to link the vote later.
            await setDoc(doc(firestore, 'sessions', user.uid), {
                matricNumber: verifiedData.matricNumber,
                verifiedAt: new Date(),
            });

            setIsVerifyingOtvp(false);
            router.push('/vote/dashboard');
        } catch (error) {
            console.error("Anonymous sign-in or session doc creation failed:", error);
            toast({ variant: 'destructive', title: 'Authentication Failed', description: 'Could not create a voting session.' });
            setIsVerifyingOtvp(false);
        }
    }

    const handleResend = () => {
        if (selectedMethod) {
            setOtvp('');
            handleSendOtvp(selectedMethod);
        }
    }
    
    const handleChangeMethod = () => {
        setStep('confirmation');
        setOtvp('');
        setSelectedMethod(null);
    }

    const renderStep = () => {
        switch (step) {
            case 'verifying':
                return (
                    <>
                        <CardHeader className="text-center">
                            <div className="mx-auto bg-primary text-primary-foreground rounded-full h-16 w-16 flex items-center justify-center mb-4">
                                <ShieldCheck className="h-8 w-8" />
                            </div>
                            <CardTitle className="font-headline text-3xl">Voter Verification</CardTitle>
                            <CardDescription>Please enter your details to proceed.</CardDescription>
                        </CardHeader>
                        <CardContent>
                        <Form {...form}>
                            <form onSubmit={form.handleSubmit(onVerifySubmit)} className="space-y-6">
                            <FormField
                                control={form.control}
                                name="matricNumber"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Matric No/Jamb Reg No</FormLabel>
                                    <FormControl>
                                    <Input placeholder="2021/BS/20311 or 202210666194DF" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="department"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Department</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger>
                                        <SelectValue placeholder="Select your department" />
                                        </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        {departments.map(dep => <SelectItem key={dep} value={dep}>{dep}</SelectItem>)}
                                    </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="level"
                                render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Level</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger>
                                        <SelectValue placeholder="Select your level" />
                                        </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        {levels.map(lvl => <SelectItem key={lvl} value={lvl}>{lvl}</SelectItem>)}
                                    </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                                )}
                            />
                            <Button type="submit" className="w-full" disabled={isSubmitting}>
                                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Verify Student
                            </Button>
                            </form>
                        </Form>
                        </CardContent>
                    </>
                );
            case 'confirmation':
                return (
                     <>
                        <CardHeader className="text-center">
                            <div className="mx-auto bg-primary text-primary-foreground rounded-full h-16 w-16 flex items-center justify-center mb-4">
                                <UserCheck className="h-8 w-8" />
                            </div>
                            <CardTitle className="font-headline text-3xl">Confirm Your Details</CardTitle>
                            <CardDescription>Please confirm your information is correct to receive your OTVP.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {voterDetails && (
                                <div className="space-y-2 rounded-lg border p-4">
                                   <VoterDetail label="Full Name" value={voterDetails.fullName} />
                                   <VoterDetail label="Department" value={voterDetails.department} />
                                   <VoterDetail label="Level" value={voterDetails.level} />
                                   <VoterDetail label="Email" value={maskString(voterDetails.email, 2, 10)} />
                                   <VoterDetail label="Phone" value={maskString(voterDetails.phone, 3, 3)} />
                                </div>
                            )}
                            <div className="space-y-3">
                                <p className="text-sm text-center text-muted-foreground">Receive your One-Time Verification PIN (OTVP) via:</p>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                    <Button onClick={() => handleSendOtvp('Email')} disabled={!!sendingMethod}>
                                        {sendingMethod === 'Email' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Mail className="mr-2 h-4 w-4" />} Email
                                    </Button>
                                    <Button onClick={() => handleSendOtvp('WhatsApp')} disabled={!!sendingMethod}>
                                        {sendingMethod === 'WhatsApp' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <MessageSquare className="mr-2 h-4 w-4" />} WhatsApp
                                    </Button>
                                    <Button onClick={() => handleSendOtvp('SMS')} disabled={!!sendingMethod}>
                                        {sendingMethod === 'SMS' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Smartphone className="mr-2 h-4 w-4" />} SMS
                                    </Button>
                                </div>
                            </div>
                            <Button variant="link" size="sm" onClick={() => setStep('verifying')} className="w-full">Not you? Go back</Button>
                        </CardContent>
                    </>
                );
            case 'enteringOtvp':
                return (
                     <>
                        <CardHeader className="text-center">
                            <div className="mx-auto bg-primary text-primary-foreground rounded-full h-16 w-16 flex items-center justify-center mb-4">
                                <KeyRound className="h-8 w-8" />
                            </div>
                            <CardTitle className="font-headline text-3xl">Enter OTVP</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <Alert>
                                <KeyRound className="h-4 w-4" />
                                <AlertTitle>Check Your {selectedMethod}</AlertTitle>
                                <AlertDescription>
                                    A 6-digit One-Time Verification PIN has been sent. Enter '123456' for this demo.
                                </AlertDescription>
                            </Alert>
                            <Input 
                                placeholder="Enter 6-digit OTVP" 
                                maxLength={6}
                                value={otvp}
                                onChange={(e) => setOtvp(e.target.value.replace(/\D/g, ''))}
                                className="text-center text-2xl font-bold tracking-[0.5em]"
                            />
                            <Button onClick={handleVerifyOtvp} className="w-full" disabled={isVerifyingOtvp}>
                                {isVerifyingOtvp && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                                Verify & Proceed to Vote
                            </Button>
                            
                            <div className="text-center text-sm text-muted-foreground">
                                {timer > 0 ? (
                                    <p>Resend OTVP in <span className="font-bold text-primary">{timer}s</span></p>
                                ) : (
                                    <div className="flex flex-col items-center gap-1">
                                        <Button variant="link" onClick={handleResend} disabled={!!sendingMethod}>
                                            {sendingMethod ? 'Sending...' : 'Resend OTVP'}
                                        </Button>
                                    </div>
                                )}
                                 <Button variant="link" size="sm" className="text-xs" onClick={handleChangeMethod}>
                                    Use a different method?
                                 </Button>
                            </div>
                        </CardContent>
                    </>
                );
        }
    }

    return (
        <main className="flex-1 flex items-center justify-center p-4 bg-background">
        <Card className="w-full max-w-md shadow-2xl">
            {renderStep()}
        </Card>
        </main>
    );
}
