import { cn } from "@/lib/utils";

export function BrandLogo({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 150 60"
      className={cn("h-10 w-auto", className)}
      {...props}
    >
      <rect width="150" height="60" rx="10" fill="transparent" />
      <text
        x="15"
        y="40"
        fontFamily="serif"
        fontSize="32"
        fontWeight="bold"
        fill="white"
      >
        Okomba
      </text>
      <text
        x="135"
        y="50"
        fontFamily="sans-serif"
        fontSize="10"
        fill="white"
        textAnchor="end"
      >
        Analytics
      </text>
    </svg>
  );
}
