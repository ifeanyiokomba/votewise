
'use client';

import { useFirestore } from "@/firebase";
import { doc, updateDoc, query, orderBy, collection, Firestore } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Inbox, CheckCircle, Ticket, User, Calendar, MessageSquare, Mail, Phone, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useState, useMemo, memo } from "react";
import { formatDistanceToNow } from 'date-fns';
import Image from "next/image";
import { useCollection } from "@/firebase/firestore/use-collection";

interface SupportTicket {
    id: string;
    matric: string;
    issueType: string;
    description: string;
    timestamp: any;
    status: 'pending' | 'resolved';
    fullName: string;
    department: string;
    level: string;
    phoneNumber: string;
    email: string;
    whatsappNumber?: string;
    photo: string;
}

const TicketList = memo(({ firestore, onSelectTicket, selectedTicketId }: { firestore: Firestore, onSelectTicket: (ticket: SupportTicket) => void, selectedTicketId: string | null }) => {
    const ticketsQuery = useMemo(
        () => {
            // Firestore is guaranteed to be available here by the parent component.
            return query(collection(firestore, 'support-tickets'), orderBy('timestamp', 'desc'));
        },
        [firestore]
    );

    const { data: tickets, isLoading } = useCollection<SupportTicket>(ticketsQuery);

    if (isLoading && !tickets) {
        return (
            <div className="flex items-center justify-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }
    
    const pendingTickets = tickets?.filter(t => t.status === 'pending') ?? [];
    const resolvedTickets = tickets?.filter(t => t.status === 'resolved') ?? [];


    return (
        <div className="h-full flex flex-col">
            <div className="p-4 border-b">
                <h3 className="font-semibold text-lg">Ticket Queue</h3>
                <p className="text-sm text-muted-foreground">{pendingTickets.length} pending tickets</p>
            </div>
            <ScrollArea className="flex-1">
                {pendingTickets.length > 0 ? (
                    pendingTickets.map(ticket => (
                        <button
                            key={ticket.id}
                            onClick={() => onSelectTicket(ticket)}
                            className={`w-full text-left p-4 border-b hover:bg-secondary/50 transition-colors ${selectedTicketId === ticket.id ? 'bg-secondary' : ''}`}
                        >
                            <p className="font-semibold truncate">{ticket.issueType}</p>
                            <p className="text-sm text-muted-foreground truncate">{ticket.fullName} ({ticket.matric})</p>
                            <p className="text-xs text-muted-foreground mt-1">
                                {ticket.timestamp ? formatDistanceToNow(ticket.timestamp.toDate(), { addSuffix: true }) : 'just now'}
                            </p>
                        </button>
                    ))
                ) : (
                    <div className="p-8 text-center text-muted-foreground">
                        <Inbox className="h-10 w-10 mx-auto mb-2" />
                        <p>No pending tickets.</p>
                    </div>
                )}
            </ScrollArea>
             <div className="p-4 border-t">
                <h3 className="font-semibold text-lg">Resolved</h3>
            </div>
             <ScrollArea className="flex-1">
                {resolvedTickets.length > 0 ? (
                    resolvedTickets.map(ticket => (
                       <button
                            key={ticket.id}
                            onClick={() => onSelectTicket(ticket)}
                            className={`w-full text-left p-4 border-b hover:bg-secondary/50 transition-colors ${selectedTicketId === ticket.id ? 'bg-secondary' : ''}`}
                        >
                            <p className="font-semibold truncate text-muted-foreground line-through">{ticket.issueType}</p>
                            <p className="text-sm text-muted-foreground truncate">{ticket.fullName}</p>
                        </button>
                    ))
                ) : (
                     <div className="p-8 text-center text-muted-foreground">
                        <p className="text-sm">No resolved tickets yet.</p>
                    </div>
                )}
            </ScrollArea>
        </div>
    );
});
TicketList.displayName = 'TicketList';


export function AdminChatConsole() {
    const firestore = useFirestore();
    const { toast } = useToast();
    const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);

    const handleSelectTicket = (ticket: SupportTicket) => {
        setSelectedTicket(ticket);
    };

    const handleMarkResolved = async (ticketId: string) => {
        if (!firestore) return;
        const ticketRef = doc(firestore, 'support-tickets', ticketId);
        try {
            await updateDoc(ticketRef, { status: 'resolved' });
            if (selectedTicket?.id === ticketId) {
                setSelectedTicket(prev => prev ? { ...prev, status: 'resolved' } : null);
            }
            toast({ title: "Success", description: "Ticket marked as resolved." });
        } catch (error) {
            console.error("Error resolving ticket:", error);
            toast({ variant: 'destructive', title: "Error", description: "Could not update the ticket." });
        }
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 h-full gap-4">
            <div className="col-span-1 flex flex-col border rounded-lg">
                {!firestore ? (
                    <div className="flex items-center justify-center h-full">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        <span className="ml-2">Connecting...</span>
                    </div>
                ) : (
                    <TicketList 
                        firestore={firestore}
                        onSelectTicket={handleSelectTicket}
                        selectedTicketId={selectedTicket?.id || null}
                    />
                )}
            </div>
            <div className="col-span-2">
                <Card className="h-full flex flex-col">
                     <CardContent className="p-6 flex-1">
                        {selectedTicket ? (
                             <ScrollArea className="h-full pr-4">
                                <div className="border-b pb-4 mb-4">
                                     <div className="flex justify-between items-center">
                                         <Badge variant={selectedTicket.status === 'resolved' ? 'secondary' : 'default'} className="capitalize">
                                             {selectedTicket.status}
                                         </Badge>
                                         {selectedTicket.status === 'pending' && (
                                             <Button size="sm" onClick={() => handleMarkResolved(selectedTicket.id)}>
                                                 <CheckCircle className="mr-2 h-4 w-4" />
                                                 Mark as Resolved
                                             </Button>
                                         )}
                                     </div>
                                     <h2 className="font-headline text-2xl font-bold mt-2">{selectedTicket.issueType}</h2>
                                 </div>

                                 <div className="grid md:grid-cols-2 gap-x-8 gap-y-4 text-sm">
                                    <div className="space-y-4">
                                        <h3 className="font-semibold text-lg">Voter Details</h3>
                                        <div className="flex items-center gap-3">
                                            <User className="h-5 w-5 text-muted-foreground"/>
                                            <span className="font-semibold w-24">Full Name:</span>
                                            <span>{selectedTicket.fullName}</span>
                                        </div>
                                         <div className="flex items-center gap-3">
                                            <Ticket className="h-5 w-5 text-muted-foreground"/>
                                            <span className="font-semibold w-24">Matric/Reg No:</span>
                                            <span>{selectedTicket.matric}</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <Mail className="h-5 w-5 text-muted-foreground"/>
                                            <span className="font-semibold w-24">Email:</span>
                                            <a href={`mailto:${selectedTicket.email}`} className="text-primary hover:underline truncate">{selectedTicket.email}</a>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <Phone className="h-5 w-5 text-muted-foreground"/>
                                            <span className="font-semibold w-24">Phone:</span>
                                            <span>{selectedTicket.phoneNumber}</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <MessageSquare className="h-5 w-5 text-muted-foreground"/>
                                            <span className="font-semibold w-24">WhatsApp:</span>
                                            <a href={`https://wa.me/${selectedTicket.whatsappNumber || selectedTicket.phoneNumber}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline flex items-center gap-1">
                                                {selectedTicket.whatsappNumber || 'N/A'} <ExternalLink className="h-3 w-3"/>
                                            </a>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <Calendar className="h-5 w-5 text-muted-foreground"/>
                                            <span className="font-semibold w-24">Reported:</span>
                                            <span>{selectedTicket.timestamp ? formatDistanceToNow(selectedTicket.timestamp.toDate(), { addSuffix: true }) : 'N/A'}</span>
                                        </div>
                                    </div>
                                     <div className="space-y-2">
                                        <h3 className="font-semibold text-lg">Live Verification Photo</h3>
                                        <div className="relative aspect-video w-full max-w-sm bg-secondary rounded-md overflow-hidden">
                                            {selectedTicket.photo ? (
                                                <Image src={selectedTicket.photo} alt="Voter verification" layout="fill" objectFit="cover" />
                                            ): (
                                                <div className="flex items-center justify-center h-full text-muted-foreground">No photo provided</div>
                                            )}
                                        </div>
                                     </div>

                                 </div>

                                <Separator className="my-6"/>

                                <div className="space-y-2 pt-2">
                                    <h4 className="font-semibold flex items-center gap-2"><MessageSquare className="h-5 w-5"/>Voter's Description</h4>
                                    <div className="p-4 bg-secondary/50 rounded-md whitespace-pre-wrap break-words min-h-[80px]">
                                        {selectedTicket.description || "No additional details provided by the voter."}
                                    </div>
                                </div>
                             </ScrollArea>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                                <Inbox className="h-16 w-16 mb-4" />
                                <h3 className="text-lg font-semibold">Select a ticket to view details</h3>
                                <p className="text-sm">Choose a ticket from the queue on the left to get started.</p>
                            </div>
                        )}
                     </CardContent>
                </Card>
            </div>
        </div>
    );
}

    