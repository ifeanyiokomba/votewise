
'use client';

import { useState, useRef, useEffect } from 'react';
import { useFirestore } from '@/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, MessageSquare, Camera, AlertTriangle, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { departments, levels } from '@/lib/data';

export function AutomatedChatbot() {
  const [step, setStep] = useState(0);
  const [matric, setMatric] = useState('');
  const [issueType, setIssueType] = useState('');
  const [description, setDescription] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // New state for 'Voter not in database'
  const [fullName, setFullName] = useState('');
  const [department, setDepartment] = useState('');
  const [level, setLevel] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  // Camera state
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState(false);
  
  const firestore = useFirestore();
  const { toast } = useToast();

  const issues = ['Verification Error', 'OTP Not Received', 'Voting Dashboard Issue', 'Voter detail not in database', 'Incorrect details like name, email, phone number, matric No', 'Other'];

  const resetForm = () => {
    setStep(0);
    setMatric('');
    setIssueType('');
    setDescription('');
    setFullName('');
    setDepartment('');
    setLevel('');
    setPhoneNumber('');
    setEmail('');
    setWhatsappNumber('');
    setCapturedImage(null);
    setIsSubmitting(false);
    setHasCameraPermission(false);
    // Stop camera stream
     if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  }

  const handleSubmit = async () => {
    if (!firestore) return;
    
    if (!capturedImage) {
        toast({ variant: 'destructive', title: 'Photo Required', description: 'Please capture a photo to verify your identity.' });
        return;
    }
    
    setIsSubmitting(true);
    try {
      const ticketData = {
        matric,
        issueType,
        description,
        timestamp: serverTimestamp(),
        status: 'pending',
        fullName,
        department,
        level,
        phoneNumber,
        email,
        whatsappNumber,
        photo: capturedImage,
      };

      await addDoc(collection(firestore, 'support-tickets'), ticketData);
      setStep(99); // Use a unique number for the final success step
    } catch (error) {
      console.error("Error submitting ticket: ", error);
      toast({ variant: 'destructive', title: 'Submission Failed', description: 'Could not submit your ticket. Please try again.' });
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setIsOpen(false);
    // Delay resetting form to allow for closing animation
    setTimeout(() => {
        resetForm();
    }, 300);
  }

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        context?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        setCapturedImage(canvas.toDataURL('image/png'));
        
        // Stop camera after capture
        if (videoRef.current?.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            videoRef.current.srcObject = null;
        }
    }
  };

   useEffect(() => {
    // Activate camera when moving to the capture step
    if (step === 3 && !capturedImage) {
        const getCameraPermission = async () => {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
             toast({ variant: 'destructive', title: 'Camera not supported', description: 'Your browser does not support camera access.'});
             setHasCameraPermission(false);
             return;
        }
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            setHasCameraPermission(true);
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
        } catch (error) {
            console.error('Error accessing camera:', error);
            setHasCameraPermission(false);
            toast({
                variant: 'destructive',
                title: 'Camera Access Denied',
                description: 'Please enable camera permissions in your browser settings to continue.',
            });
        }
        };

        getCameraPermission();
    }
   }, [step, capturedImage, toast]);


  const renderStepContent = () => {
    switch (step) {
      case 0:
        return (
          <>
            <DialogHeader>
              <DialogTitle>Report an Issue</DialogTitle>
              <DialogDescription>What's your Matric No/Jamb Reg No?</DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Input 
                value={matric} 
                onChange={(e) => setMatric(e.target.value)} 
                placeholder="e.g., 2021/BS/20311" 
              />
            </div>
            <DialogFooter>
              <Button onClick={() => setStep(1)} disabled={!matric.trim()}>Next</Button>
            </DialogFooter>
          </>
        );
      case 1:
        return (
          <>
            <DialogHeader>
              <DialogTitle>Describe the Issue</DialogTitle>
              <DialogDescription>What issue are you facing?</DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <Select onValueChange={setIssueType} value={issueType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Issue Type" />
                </SelectTrigger>
                <SelectContent>
                  {issues.map(issue => <SelectItem key={issue} value={issue}>{issue}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setStep(0)}>Back</Button>
              <Button onClick={() => setStep(2)} disabled={!issueType}>Next</Button>
            </DialogFooter>
          </>
        );
        case 2:
            return (
                <>
                <DialogHeader>
                    <DialogTitle>Enter Your Details</DialogTitle>
                    <DialogDescription>Please provide your full details for manual verification.</DialogDescription>
                </DialogHeader>
                 <div className="py-4 space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                    <Input placeholder="Full Name" value={fullName} onChange={e => setFullName(e.target.value)} />
                    <Select onValueChange={setDepartment} value={department}>
                        <SelectTrigger><SelectValue placeholder="Select Department" /></SelectTrigger>
                        <SelectContent>{departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select onValueChange={setLevel} value={level}>
                        <SelectTrigger><SelectValue placeholder="Select Level" /></SelectTrigger>
                        <SelectContent>{levels.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
                    </Select>
                    <Input type="tel" placeholder="Phone Number" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} />
                    <Input type="email" placeholder="Email Address" value={email} onChange={e => setEmail(e.target.value)} />
                    <Input type="tel" placeholder="WhatsApp Number (optional)" value={whatsappNumber} onChange={e => setWhatsappNumber(e.target.value)} />
                    
                    <Textarea 
                        value={description} 
                        onChange={(e) => setDescription(e.target.value)} 
                        placeholder="Please describe your issue in detail... (optional)"
                        className="mt-2"
                    />
                </div>
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
                    <Button onClick={() => setStep(3)} disabled={!fullName || !department || !level || !phoneNumber || !email}>
                        Proceed to Verification
                    </Button>
                </DialogFooter>
                </>
            );
        case 3:
            return (
                <>
                    <DialogHeader>
                        <DialogTitle>Live Photo Verification</DialogTitle>
                        <DialogDescription>Please capture a live photo to verify your identity.</DialogDescription>
                    </DialogHeader>
                    <div className="py-4 space-y-3">
                         <div className="space-y-2">
                            {capturedImage ? (
                                <div className="text-center">
                                    <img src={capturedImage} alt="Captured" className="rounded-md mx-auto w-full aspect-video object-cover" />
                                    <Button variant="link" size="sm" onClick={() => {setCapturedImage(null);}}>Retake Photo</Button>
                                </div>
                            ) : (
                                <>
                                    <div className="relative bg-secondary rounded-md overflow-hidden aspect-video flex items-center justify-center">
                                        <video ref={videoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
                                        {!hasCameraPermission && (
                                            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 bg-black/50">
                                                <AlertTriangle className="h-8 w-8 text-yellow-400 mb-2"/>
                                                <p className="text-sm text-white">Camera access is required. Please allow permission in your browser.</p>
                                            </div>
                                        )}
                                    </div>
                                    <Button onClick={handleCapture} className="w-full mt-2" disabled={!hasCameraPermission}>
                                        <Camera className="mr-2 h-4 w-4" /> Capture Photo
                                    </Button>
                                </>
                            )}
                            <canvas ref={canvasRef} className="hidden"></canvas>
                        </div>
                    </div>
                     <DialogFooter>
                        <Button variant="ghost" onClick={() => setStep(2)}>Back</Button>
                        <Button onClick={handleSubmit} disabled={isSubmitting || !capturedImage}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : 'Submit Ticket'}
                        </Button>
                    </DialogFooter>
                </>
            );
        case 99:
            return (
                <>
                <DialogHeader className="text-center">
                    <div className="mx-auto bg-green-100 text-green-700 rounded-full h-16 w-16 flex items-center justify-center mb-4">
                        <CheckCircle className="h-8 w-8" />
                    </div>
                    <DialogTitle>Submission Successful!</DialogTitle>
                    <DialogDescription>An admin will contact you soon via email or WhatsApp to resolve your issue.</DialogDescription>
                </DialogHeader>
                <DialogFooter className="pt-4">
                    <Button onClick={handleClose} className="w-full">Close</Button>
                </DialogFooter>
                </>
            );
    }
  };

  return (
    <>
        <div className="fixed bottom-4 right-4 z-50">
            <div>
                <Button
                    size="icon"
                    className="h-14 w-14 rounded-full shadow-2xl"
                    onClick={() => setIsOpen(true)}
                    aria-label="Report an Issue"
                >
                    <MessageSquare className="h-7 w-7" />
                </Button>
            </div>
        </div>

        <Dialog open={isOpen} onOpenChange={(open) => { if(!open) handleClose()}}>
            <DialogContent onInteractOutside={(e) => e.preventDefault()}>
                {renderStepContent()}
            </DialogContent>
        </Dialog>
    </>
  );
}
