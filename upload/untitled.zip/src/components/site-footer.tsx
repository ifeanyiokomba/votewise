import { BrandLogo } from '@/components/brand-logo';

export function SiteFooter() {
  return (
    <footer className="bg-secondary/10 border-t mt-12">
      <div className="container mx-auto px-4 py-6 flex items-center justify-center">
        <a href="https://www.okomba.com" target="_blank" rel="noopener noreferrer" aria-label="Okomba Website">
          <BrandLogo className="h-6 w-auto text-foreground/80 hover:text-foreground transition-colors" />
        </a>
        <span className="text-sm text-muted-foreground ml-2">© All rights reserved</span>
      </div>
    </footer>
  );
}
