
'use server';
import * as admin from 'firebase-admin';

let app: admin.app.App;
let appInitialized = false;


/**
 * Initializes and/or returns the Firebase Admin App instance.
 * It now correctly uses environment variables for reliability.
 */
export async function getAdminApp(): Promise<admin.app.App> {
  if (appInitialized && app) {
    return app;
  }
  
  if (admin.apps.length > 0 && admin.apps[0]) {
    app = admin.apps[0];
    appInitialized = true;
    return app;
  }
  
  // Check if credentials are available in environment variables
  if (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY) {
    const serviceAccount: admin.ServiceAccount = {
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: (process.env.FIREBASE_PRIVATE_KEY).replace(/\\n/g, '\n'),
    };
     try {
        app = admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            storageBucket: `${process.env.FIREBASE_PROJECT_ID}.appspot.com`
        });
        appInitialized = true;
        return app;
    } catch (e: any) {
        if (e.code === 'app/duplicate-app' && admin.apps[0]) {
            app = admin.apps[0];
            appInitialized = true;
            return app;
        }
        console.error('Failed to initialize Firebase Admin SDK with service account: ' + e.message);
        throw e;
    }

  } else {
    console.warn(`
      ********************************************************************************
      ** WARNING: FIREBASE ADMIN SDK CREDENTIALS NOT FOUND IN .env **
      ********************************************************************************
      * The Firebase Admin SDK environment variables (FIREBASE_PROJECT_ID,
      * FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY) are not set.
      *
      * The application server will attempt to initialize using Application
      * Default Credentials, which should work in a deployed App Hosting
      * environment but will likely fail during local development if an admin
      * feature is used.
      *
      * To fix for local development, get your project's service account key
      * from the Firebase console and add the credentials to the .env file.
      ********************************************************************************
    `);

    // Attempt to initialize without credentials. This works in deployed environments.
    try {
        app = admin.initializeApp();
        appInitialized = true;
        return app;
    } catch (e: any) {
         if (e.code === 'app/duplicate-app' && admin.apps[0]) {
            app = admin.apps[0];
            appInitialized = true;
            return app;
        }
        console.error('Failed to initialize Firebase Admin SDK with default credentials: ' + e.message);
        throw e;
    }
  }
}


/**
 * A centralized error handler for admin SDK operations.
 * It logs the detailed error and returns a user-friendly message.
 * @param error - The error object.
 * @param operation - A description of what was being attempted (e.g., "saving election settings").
 * @returns An object with success: false and a user-friendly error message.
 */
export async function handleAdminError(error: any, operation: string): Promise<{ success: false; message: string }> {
    console.error(`Admin SDK Error during ${operation}:`, error);

    if (error.code === 'permission-denied') {
        return { success: false, message: `Firestore Permission Denied: You do not have permission to ${operation}.` };
    }
    
    // Check for authentication token errors, which can happen if .env is not set up correctly.
    if (error.code === 2 || (error.message && error.message.includes('Could not refresh access token'))) {
         return { success: false, message: 'Server authentication failed. Please ensure your Firebase Admin SDK credentials in the .env file are correct and valid.' };
    }

    if (error.message && error.message.includes('Service account credentials are not set')) {
        return { success: false, message: 'The server is not configured for this admin action. Please set the Firebase Admin SDK credentials in your .env file for local development.' };
    }

    return { success: false, message: `A server error occurred while ${operation}.` };
}
