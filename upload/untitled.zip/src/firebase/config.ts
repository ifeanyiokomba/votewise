export const firebaseConfig = {
  "projectId": "studio-4825710343-7f2dd",
  "appId": "1:706579850741:web:ea948299398510c59a6cbc",
  "apiKey": "AIzaSyD2RXPRcW1jtAXi760eA9g2wGJ129Dyztk",
  "authDomain": "studio-4825710343-7f2dd.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "706579850741"
};
