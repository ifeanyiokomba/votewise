import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState(false)

  React.useEffect(() => {
    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    checkIsMobile();
    window.addEventListener("change", checkIsMobile)
    return () => window.removeEventListener("change", checkIsMobile)
  }, [])

  return isMobile
}
