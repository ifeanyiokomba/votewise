
import { PlaceHolderImages } from '@/lib/placeholder-images';
import type { ChartConfig } from '@/components/ui/chart';

export const departments = [
  'Biotechnology', 
  'Microbiology', 
  'Biochemistry', 
  'Biology'
];

export const levels = [
  '100 Level', '200 Level', '300 Level', '400 Level'
];

export const positions = [
    'President', 
    'Vice President', 
    'Secretary General', 
    'Assistant Secretary General', 
    'Treasurer', 
    'Financial Secretary', 
    'Director of Information', 
    'Director of Socials', 
    'Director of Sports',
    'Director of Welfare',
    'Director of Academics',
    'Internal Auditor',
    'Provost Marshal'
];


const getImage = (id: string) => PlaceHolderImages.find(img => img.id === id)?.imageUrl || '';

export const contestants = {
  President: [
    { id: 'pres1', name: 'Adebayo Adewale', department: 'Computer Science', photoUrl: getImage('contestant1'), phrase: 'Leading with Vision' },
    { id: 'pres2', name: 'Chiamaka Nwosu', department: 'Mass Communication', photoUrl: getImage('contestant2'), phrase: 'Your Voice, Your Choice' },
  ],
  'Vice President': [
    { id: 'vp1', name: 'Musa Ibrahim', department: 'Law', photoUrl: getImage('contestant3'), phrase: 'For a Better Union' },
  ],
  'Secretary General': [
      { id: 'sec1', name: 'Fatima Bello', department: 'Biochemistry', photoUrl: getImage('contestant4'), phrase: 'Progress and Transparency' },
      { id: 'sec2', name: 'David Okon', department: 'Civil Engineering', photoUrl: getImage('contestant5'), phrase: 'Building Our Future' },
  ]
};

export const electionResults = [
  { name: 'Adebayo Adewale', votes: 1254, fill: 'var(--color-adebayo)' },
  { name: 'Chiamaka Nwosu', votes: 980, fill: 'var(--color-chiamaka)' },
  { name: 'Musa Ibrahim', votes: 2234, fill: 'var(--color-chiamaka)' },
  { name: 'Fatima Bello', votes: 1560, fill: 'var(--color-chiamaka)' },
];

export const electionWinners = {
    President: { ...contestants.President[0], votes: 1254 },
    'Vice President': { ...contestants['Vice President'][0], votes: 2234 },
    'Secretary General': { ...contestants['Secretary General'][0], votes: 1560 },
};

export const resultsChartConfig = {
  votes: {
    label: 'Votes',
  },
  adebayo: {
    label: 'Adebayo Adewale',
    color: 'hsl(var(--chart-1))',
  },
  chiamaka: {
    label: 'Chiamaka Nwosu',
    color: 'hsl(var(--chart-2))',
  },
} satisfies ChartConfig;


export const departmentAnalytics = [
    { department: 'Comp. Sci', votes: 186, fill: 'var(--color-department1)' },
    { department: 'Law', votes: 205, fill: 'var(--color-department2)'  },
    { department: 'Medicine', votes: 275, fill: 'var(--color-department3)'  },
    { department: 'Engineering', votes: 150, fill: 'var(--color-department4)'  },
    { department: 'Business Admin', votes: 210, fill: 'var(--color-department5)'  },
    { department: 'Arts', votes: 120, fill: 'var(--color-department6)'  },
]

export const departmentChartConfig = {
  votes: {
    label: "Votes",
  },
  department1: { label: "Comp. Sci", color: "hsl(var(--chart-1))" },
  department2: { label: "Law", color: "hsl(var(--chart-2))" },
  department3: { label: "Medicine", color: "hsl(var(--chart-3))" },
  department4: { label: "Engineering", color: "hsl(var(--chart-4))" },
  department5: { label: "Business Admin", color: "hsl(var(--chart-5))" },
  department6: { label: "Arts", color: "hsl(var(--chart-1))" },
} satisfies ChartConfig

export const levelAnalytics = [
  { level: "100 Level", votes: 400, fill: "hsl(var(--chart-1))" },
  { level: "200 Level", votes: 300, fill: "hsl(var(--chart-2))" },
  { level: "300 Level", votes: 300, fill: "hsl(var(--chart-3))" },
  { level: "400 Level", votes: 200, fill: "hsl(var(--chart-4))" },
  { level: "500+ Level", votes: 250, fill: "hsl(var(--chart-5))" },
]

export const levelChartConfig = {
  votes: {
    label: "Votes",
  },
  "100 Level": {
    label: "100 Level",
    color: "hsl(var(--chart-1))",
  },
  "200 Level": {
    label: "200 Level",
    color: "hsl(var(--chart-2))",
  },
  "300 Level": {
    label: "300 Level",
    color: "hsl(var(--chart-3))",
  },
  "400 Level": {
    label: "400 Level",
    color: "hsl(var(--chart-4))",
  },
  "500+ Level": {
    label: "500+ Level",
    color: "hsl(var(--chart-5))",
  },
} satisfies ChartConfig

export const mockVoterActivity = [
    {
        id: "1",
        name: "Adebisi Chukwuma",
        matric: "2021/CS/20311",
        department: "Computer Science",
        level: "300 Level",
        loginTime: "2025-10-13T08:01:15Z",
        otpSendTime: "2025-10-13T08:01:45Z",
        otpVerifyTime: "2025-10-13T08:02:10Z",
        voteTime: "2025-10-13T08:05:30Z",
        logoutTime: "2025-10-13T08:06:00Z",
        status: "Voted"
    },
    {
        id: "2",
        name: "Ngozi Okoro",
        matric: "2022/LW/21422",
        department: "Law",
        level: "200 Level",
        loginTime: "2025-10-13T08:03:20Z",
        otpSendTime: "2025-10-13T08:03:55Z",
        otpVerifyTime: null,
        voteTime: null,
        logoutTime: null,
        status: "Pending OTP"
    },
     {
        id: "3",
        name: "Ibrahim Sadiq",
        matric: "2020/ME/19001",
        department: "Mechanical Engineering",
        level: "400 Level",
        loginTime: "2025-10-13T08:04:00Z",
        otpSendTime: "2025-10-13T08:04:20Z",
        otpVerifyTime: "2025-10-13T08:04:55Z",
        voteTime: null,
        logoutTime: null,
        status: "In Progress"
    },
    {
        id: "4",
        name: "Fatima Aliyu",
        matric: "2023/BA/22505",
        department: "Business Administration",
        level: "100 Level",
        loginTime: "2025-10-13T08:05:00Z",
        otpSendTime: null,
        otpVerifyTime: null,
        voteTime: null,
        logoutTime: null,
        status: "Logged In"
    }
];
