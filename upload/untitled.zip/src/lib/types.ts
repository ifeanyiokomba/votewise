
import { Timestamp } from 'firebase/firestore';

export interface AuditLog {
    id: string;
    userId: string;
    userName: string;
    userRole: 'admin' | 'observer';
    action: string;
    details: Record<string, any>;
    timestamp: Timestamp;
}
