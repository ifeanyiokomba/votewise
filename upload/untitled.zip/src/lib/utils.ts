import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function maskString(
  str: string | undefined | null,
  visibleStart: number,
  visibleEnd: number
): string {
  if (!str) return '';
  const start = str.substring(0, visibleStart);
  const end = str.substring(str.length - visibleEnd);
  const masked = '*'.repeat(Math.max(0, str.length - visibleStart - visibleEnd));
  return start + masked + end;
}
